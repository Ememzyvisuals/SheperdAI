# 🙏 ShepherdAI
### Your 24/7 AI Christian Companion
**by EMEMZYVISUALS DIGITALS**

---

## Overview

ShepherdAI is a production-ready WhatsApp bot that serves as an AI-powered Christian companion. It helps believers grow spiritually through conversations, devotionals, prayers, Bible teaching, and encouragement — in **5 Nigerian languages**.

---

## Tech Stack (All Verified)

| Layer | Technology | Version/Model |
|-------|-----------|---------------|
| WhatsApp | @whiskeysockets/baileys | 6.7.21 |
| AI Chat | Groq — llama-3.3-70b-versatile | Primary |
| AI Fallback | Groq — llama-3.1-8b-instant | Fallback |
| TTS (EN/Pidgin) | Groq Orpheus — canopylabs/orpheus-v1-english | daniel voice |
| TTS (Yoruba) | HuggingFace — facebook/mms-tts-yor | MMS |
| TTS (Igbo) | HuggingFace — facebook/mms-tts-ibo | MMS |
| TTS (Hausa) | HuggingFace — facebook/mms-tts-hau | MMS |
| STT | Groq — whisper-large-v3-turbo | Primary |
| STT Fallback | HuggingFace — openai/whisper-large-v3 | Fallback |
| Database | Supabase (PostgreSQL REST API) | — |
| Scheduler | node-cron | ^3.0.3 |
| Runtime | Node.js | >=18 |
| Deployment | Render Background Worker | — |

---

## Features

- ✅ WhatsApp pairing code login (no QR)
- ✅ Anti-ban: message queue, typing simulation, rate limiter, chunking
- ✅ AI chat powered by Groq llama-3.3-70b
- ✅ 5 languages: English, Pidgin, Yoruba, Igbo, Hausa
- ✅ Voice notes: send & receive (STT + TTS)
- ✅ Daily devotionals (scheduled)
- ✅ Prayer request logging
- ✅ Bible verse search by topic
- ✅ Bible quiz with score tracking
- ✅ Faith streaks gamification
- ✅ Group detection + moderation
- ✅ Owner-only admin commands
- ✅ Supabase backend
- ✅ Express health endpoint for Render

---

## Project Structure

```
shepherdai/
├── src/
│   ├── config/
│   │   └── index.js              # All env + model config
│   ├── connection/
│   │   └── index.js              # Baileys socket + pairing code
│   ├── handlers/
│   │   ├── messageHandler.js     # Core message routing
│   │   └── groupHandler.js       # Group events
│   ├── commands/
│   │   └── index.js              # All /commands
│   ├── services/
│   │   ├── groqService.js        # Chat, TTS, STT
│   │   ├── bibleEngine.js        # Verse DB + quiz
│   │   ├── voiceService.js       # Voice note pipeline
│   │   ├── moderationService.js  # Group moderation
│   │   └── conversationCache.js  # In-memory history
│   ├── tts/
│   │   └── huggingfaceTTS.js     # HF MMS TTS
│   ├── database/
│   │   ├── supabase.js           # All DB operations
│   │   └── schema.sql            # DB schema (run once)
│   ├── scheduler/
│   │   └── index.js              # node-cron devotionals
│   ├── utils/
│   │   ├── logger.js             # Pino logger
│   │   ├── delay.js              # Human delay utils
│   │   ├── rateLimiter.js        # Per-user rate limit
│   │   ├── messageQueue.js       # Sequential send queue
│   │   ├── chunkMessage.js       # Long message splitter
│   │   ├── languageRouter.js     # Language detection
│   │   └── ttsRouter.js          # TTS provider routing
│   ├── server.js                 # Express health server
│   └── index.js                  # Entry point
├── .env.example
├── .gitignore
├── package.json
├── render.yaml
└── README.md
```

---

## Setup

### 1. Clone and install

```bash
git clone <your-repo>
cd shepherdai
npm install
```

### 2. Configure environment

```bash
cp .env.example .env
# Fill in your real keys in .env
```

### 3. Set up Supabase database

1. Go to your Supabase project → SQL Editor
2. Paste and run `src/database/schema.sql`

### 4. Run locally

```bash
npm start
```

When first run, you will see a **pairing code** in the terminal:

```
╔══════════════════════════════════════╗
║       ShepherdAI — PAIRING CODE      ║
╠══════════════════════════════════════╣
║   CODE:  ABCD-EFGH                   ║
╚══════════════════════════════════════╝
```

On your phone:
1. Open WhatsApp → Settings → Linked Devices
2. Tap **Link with phone number**
3. Enter the code shown

---

## Deploy to Render

1. Push code to GitHub
2. On Render: **New → Background Worker**
3. Connect your repo
4. Add all environment variables from `.env.example`
5. Build command: `npm install`
6. Start command: `npm start`
7. Deploy

---

## Commands

| Command | Description |
|---------|-------------|
| `/help` | Show all commands |
| `/verse <topic>` | Bible verses on a topic |
| `/devotional` | Today's devotional |
| `/pray <request>` | Generate a prayer |
| `/sermon <topic>` | Sermon outline |
| `/quiz` | Bible quiz question |
| `/streak` | Your faith streak |
| `/voice` | Voice devotional |
| `/language` | Change language |
| `/reset` | Clear chat history |
| `/about` | About ShepherdAI |

### Owner Commands

| Command | Description |
|---------|-------------|
| `/broadcast <msg>` | Message all users |
| `/users` | User count |
| `/stats` | Bot statistics |
| `/restart` | Restart bot |

---

## Anti-Ban Architecture

| Protection | Implementation |
|-----------|---------------|
| Message queue | All sends sequential, never parallel |
| Typing simulation | composing → delay → paused → send |
| Human-speed delay | 2–8s scaled to message length |
| Rate limiting | 10/min, 100/hr per user |
| Message chunking | Splits at 4000 chars at sentence boundaries |
| Safe broadcast | Only to prior-interacting users |
| Group control | Responds only when mentioned/commanded |

---

## Language & TTS Routing

| Language | TTS Provider | Model |
|----------|-------------|-------|
| English | Groq Orpheus | canopylabs/orpheus-v1-english |
| Pidgin | Groq Orpheus | canopylabs/orpheus-v1-english |
| Yoruba | HuggingFace MMS | facebook/mms-tts-yor |
| Igbo | HuggingFace MMS | facebook/mms-tts-ibo |
| Hausa | HuggingFace MMS | facebook/mms-tts-hau |

---

## Developer

**EMEMZYVISUALS DIGITALS**

_"Your word is a lamp to my feet and a light to my path." — Psalm 119:105_

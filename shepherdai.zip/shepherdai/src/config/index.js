// ============================================================
// ShepherdAI — Configuration
// EMEMZYVISUALS DIGITALS
// ============================================================

import dotenv from 'dotenv';
dotenv.config();

export const config = {
  // Identity
  botName: process.env.BOT_NAME || 'ShepherdAI',
  developer: process.env.DEVELOPER || 'EMEMZYVISUALS DIGITALS',
  botNumber: process.env.BOT_WHATSAPP_NUMBER || '',
  ownerNumber: process.env.OWNER_NUMBER || '',
  ownerJid: process.env.OWNER_JID || '',

  // Groq AI — Verified models (2025)
  groq: {
    apiKey: process.env.GROQ_API_KEY || '',
    baseUrl: 'https://api.groq.com/openai/v1',
    // llama3-70b-8192 deprecated May 2025 → use llama-3.3-70b-versatile
    primaryModel: 'llama-3.3-70b-versatile',
    fallbackModel: 'llama-3.1-8b-instant',
    // TTS — Orpheus (replaces PlayAI TTS, verified Dec 2025)
    ttsModel: 'canopylabs/orpheus-v1-english',
    ttsVoice: 'daniel',
    // STT — whisper-large-v3-turbo (distil-whisper deprecated)
    sttModel: 'whisper-large-v3-turbo',
  },

  // HuggingFace — MMS TTS models (verified 2025)
  huggingface: {
    token: process.env.HUGGINGFACE_TOKEN || '',
    // Serverless Inference API base
    inferenceBase: 'https://router.huggingface.co/hf-inference/models',
    models: {
      yoruba: 'facebook/mms-tts-yor',
      igbo: 'facebook/mms-tts-ibo',
      hausa: 'facebook/mms-tts-hau',
      // STT fallback
      whisper: 'openai/whisper-large-v3',
    },
  },

  // Supabase
  supabase: {
    url: process.env.SUPABASE_URL || '',
    serviceKey: process.env.SUPABASE_SERVICE_KEY || '',
    anonKey: process.env.SUPABASE_ANON_KEY || '',
  },

  // Session
  sessionPath: process.env.SESSION_PATH || './auth',

  // Server
  port: parseInt(process.env.PORT || '3000', 10),
  nodeEnv: process.env.NODE_ENV || 'development',

  // Logging
  logToFile: process.env.LOG_TO_FILE === 'true',
  logLevel: process.env.LOG_LEVEL || 'info',

  // Anti-ban timing
  minTypingDelay: parseInt(process.env.MIN_TYPING_DELAY || '2000', 10),
  maxTypingDelay: parseInt(process.env.MAX_TYPING_DELAY || '8000', 10),

  // Rate limits
  rateLimitPerMinute: parseInt(process.env.RATE_LIMIT_PER_MINUTE || '10', 10),
  rateLimitPerHour: parseInt(process.env.RATE_LIMIT_PER_HOUR || '100', 10),

  // Devotional schedule
  devotionalHour: parseInt(process.env.DEVOTIONAL_HOUR || '6', 10),
  devotionalMinute: parseInt(process.env.DEVOTIONAL_MINUTE || '0', 10),

  // Supported languages
  languages: {
    english: 'English',
    pidgin: 'Pidgin',
    yoruba: 'Yoruba',
    igbo: 'Igbo',
    hausa: 'Hausa',
  },
};

export default config;

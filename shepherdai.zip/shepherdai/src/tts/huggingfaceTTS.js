// ============================================================
// ShepherdAI — HuggingFace MMS TTS
// Models: facebook/mms-tts-yor, facebook/mms-tts-ibo, facebook/mms-tts-hau
// Endpoint: https://router.huggingface.co/hf-inference/models/{model}
// EMEMZYVISUALS DIGITALS
// ============================================================

import axios from 'axios';
import { config } from '../config/index.js';
import logger from '../utils/logger.js';

const HF_INFERENCE_BASE = config.huggingface.inferenceBase;

/**
 * Generate TTS audio via HuggingFace serverless inference
 * @param {string} text - text to synthesize
 * @param {string} modelId - e.g. "facebook/mms-tts-yor"
 * @returns {Promise<Buffer>} - audio buffer (wav)
 */
export const hfTTS = async (text, modelId) => {
  const apiUrl = `${HF_INFERENCE_BASE}/${modelId}`;

  try {
    // HF inference API for text-to-audio/TTS uses inputs as string
    const response = await axios.post(
      apiUrl,
      { inputs: text },
      {
        headers: {
          Authorization: `Bearer ${config.huggingface.token}`,
          'Content-Type': 'application/json',
          Accept: 'audio/wav',
        },
        responseType: 'arraybuffer',
        timeout: 60000,
      },
    );

    const audioBuffer = Buffer.from(response.data);
    if (audioBuffer.length < 100) {
      throw new Error('HuggingFace TTS returned empty audio');
    }

    logger.info({ modelId, bytes: audioBuffer.length }, 'HF TTS success');
    return audioBuffer;
  } catch (err) {
    const status = err.response?.status;
    const errMsg = err.response?.data
      ? Buffer.from(err.response.data).toString('utf8').slice(0, 200)
      : err.message;
    logger.error({ modelId, status, errMsg }, 'HuggingFace TTS error');
    throw new Error(`HF TTS failed: ${errMsg}`);
  }
};

/**
 * Generate TTS for a specific language
 * Maps language → HuggingFace model
 */
export const generateLanguageTTS = async (text, language) => {
  const modelMap = {
    yoruba: config.huggingface.models.yoruba,   // facebook/mms-tts-yor
    igbo: config.huggingface.models.igbo,       // facebook/mms-tts-ibo
    hausa: config.huggingface.models.hausa,     // facebook/mms-tts-hau
  };

  const modelId = modelMap[language];
  if (!modelId) {
    throw new Error(`No HF TTS model for language: ${language}`);
  }

  return hfTTS(text, modelId);
};

/**
 * Speech-to-text via HuggingFace Whisper
 * Used as fallback if Groq STT fails
 */
export const hfSTT = async (audioBuffer) => {
  const modelId = config.huggingface.models.whisper;
  const apiUrl = `${HF_INFERENCE_BASE}/${modelId}`;

  try {
    const response = await axios.post(apiUrl, audioBuffer, {
      headers: {
        Authorization: `Bearer ${config.huggingface.token}`,
        'Content-Type': 'audio/flac',
      },
      timeout: 60000,
    });

    const text =
      typeof response.data === 'string'
        ? response.data
        : response.data?.text || '';

    return text.trim();
  } catch (err) {
    logger.error({ err: err.message }, 'HF STT error');
    throw err;
  }
};

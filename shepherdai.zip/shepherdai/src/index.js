// ============================================================
//
//   ███████╗██╗  ██╗███████╗██████╗ ██╗  ██╗███████╗██████╗ ██████╗  █████╗ ██╗
//   ██╔════╝██║  ██║██╔════╝██╔══██╗██║  ██║██╔════╝██╔══██╗██╔══██╗██╔══██╗██║
//   ███████╗███████║█████╗  ██████╔╝███████║█████╗  ██████╔╝██║  ██║███████║██║
//   ╚════██║██╔══██║██╔══╝  ██╔═══╝ ██╔══██║██╔══╝  ██╔══██╗██║  ██║██╔══██║██║
//   ███████║██║  ██║███████╗██║     ██║  ██║███████╗██║  ██║██████╔╝██║  ██║██║
//   ╚══════╝╚═╝  ╚═╝╚══════╝╚═╝     ╚═╝  ╚═╝╚══════╝╚═╝  ╚═╝╚═════╝ ╚═╝  ╚═╝╚═╝
//
//   ShepherdAI — Your 24/7 AI Christian Companion
//   Developer: EMEMZYVISUALS DIGITALS
//   Powered by: Groq AI + HuggingFace + Baileys + Supabase
//
// ============================================================

import 'dotenv/config';
import { connectToWhatsApp } from './connection/index.js';
import { startServer } from './server.js';
import logger from './utils/logger.js';
import config from './config/index.js';

// ─────────────────────────────────────────────
// Startup banner
// ─────────────────────────────────────────────
const printBanner = () => {
  console.log('\n');
  console.log('╔═══════════════════════════════════════════════════╗');
  console.log('║                 🙏 ShepherdAI 🙏                  ║');
  console.log('║       Your 24/7 AI Christian Companion            ║');
  console.log('║                                                   ║');
  console.log(`║  Developer: ${config.developer.padEnd(38)}║`);
  console.log(`║  Node:      ${process.version.padEnd(38)}║`);
  console.log(`║  Env:       ${config.nodeEnv.padEnd(38)}║`);
  console.log(`║  Bot:       ${config.botNumber.padEnd(38)}║`);
  console.log('╚═══════════════════════════════════════════════════╝');
  console.log('\n');
};

// ─────────────────────────────────────────────
// Graceful shutdown
// ─────────────────────────────────────────────
const gracefulShutdown = (signal) => {
  logger.info({ signal }, 'Shutdown signal received');
  console.log(`\n🛑 ShepherdAI shutting down (${signal})...`);
  process.exit(0);
};

process.on('SIGTERM', () => gracefulShutdown('SIGTERM'));
process.on('SIGINT', () => gracefulShutdown('SIGINT'));

// ─────────────────────────────────────────────
// Unhandled errors
// ─────────────────────────────────────────────
process.on('uncaughtException', (err) => {
  logger.error({ err: err.message, stack: err.stack }, 'Uncaught exception');
  // Don't exit — keep bot running
});

process.on('unhandledRejection', (reason) => {
  logger.error({ reason: String(reason) }, 'Unhandled promise rejection');
  // Don't exit — keep bot running
});

// ─────────────────────────────────────────────
// MAIN BOOT
// ─────────────────────────────────────────────
const main = async () => {
  printBanner();

  logger.info('🚀 Starting ShepherdAI...');

  // Validate critical env vars
  const required = ['GROQ_API_KEY', 'SUPABASE_URL', 'SUPABASE_SERVICE_KEY'];
  const missing = required.filter((k) => !process.env[k]);
  if (missing.length > 0) {
    logger.error({ missing }, '❌ Missing required environment variables');
    process.exit(1);
  }

  // Start health server (required for Render deployment)
  startServer();

  // Connect to WhatsApp
  await connectToWhatsApp();
};

main().catch((err) => {
  logger.error({ err: err.message }, 'Fatal startup error');
  process.exit(1);
});

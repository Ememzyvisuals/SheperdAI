// ============================================================
// ShepherdAI — TTS Router
// Routes to Groq Orpheus (English/Pidgin) or HuggingFace MMS
// EMEMZYVISUALS DIGITALS
// ============================================================

import { generateTTS } from '../services/groqService.js';
import { generateLanguageTTS } from '../tts/huggingfaceTTS.js';
import { getTTSProvider } from './languageRouter.js';
import logger from './logger.js';

/**
 * Generate voice audio for a given text and language
 * Returns: Buffer (WAV audio) or null on total failure
 */
export const generateVoice = async (text, language = 'english') => {
  const provider = getTTSProvider(language);

  // ── Groq Orpheus (English / Pidgin) ──
  if (provider === 'groq') {
    try {
      logger.info({ language, provider: 'groq' }, 'TTS via Groq Orpheus');
      return await generateTTS(text, 'daniel');
    } catch (err) {
      logger.warn({ err: err.message }, 'Groq TTS failed, falling back to HF English');
      // Final fallback — try HF whisper-based TTS in English
      try {
        return await generateLanguageTTS(text, 'english');
      } catch (_) {
        logger.error('All TTS providers failed');
        return null;
      }
    }
  }

  // ── HuggingFace MMS (Yoruba / Igbo / Hausa) ──
  try {
    logger.info({ language, provider: 'huggingface' }, 'TTS via HuggingFace MMS');
    return await generateLanguageTTS(text, language);
  } catch (err) {
    logger.warn({ err: err.message, language }, 'HF TTS failed, falling back to Groq English');
    try {
      return await generateTTS(text, 'daniel');
    } catch (_) {
      logger.error('All TTS providers failed');
      return null;
    }
  }
};

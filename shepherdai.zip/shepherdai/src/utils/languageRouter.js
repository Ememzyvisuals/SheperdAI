// ============================================================
// ShepherdAI — Language Router
// EMEMZYVISUALS DIGITALS
// ============================================================

import { config } from '../config/index.js';

/**
 * Language welcome & selection messages
 */
export const LANGUAGE_MENU = `
🙏 *Welcome to ShepherdAI* 🙏
_Your 24/7 AI Christian Companion_
_by ${config.developer}_

Please choose your preferred language:

1️⃣ *English*
2️⃣ *Pidgin*
3️⃣ *Yoruba*
4️⃣ *Igbo*
5️⃣ *Hausa*

Reply with the number or the language name.
`.trim();

export const LANGUAGE_CONFIRMATIONS = {
  english: '✅ Great! I will respond in *English*. God bless you! 🙏',
  pidgin: '✅ Oya! I go dey answer you for *Pidgin*. God bless you! 🙏',
  yoruba: '✅ O dara! Emi yoo dahun ni *Yoruba*. Oluwa ki o bukun fun e! 🙏',
  igbo: '✅ Ọ dị mma! A ga m aza gị na *Igbo*. Chukwu gozie gị! 🙏',
  hausa: '✅ Toh! Zan amsa maka da *Hausa*. Allah ya albarka ka! 🙏',
};

/**
 * Parse user language choice from text
 * Returns language key or null
 */
export const parseLanguageChoice = (text) => {
  const t = text.toLowerCase().trim();

  if (t === '1' || t.includes('english')) return 'english';
  if (t === '2' || t.includes('pidgin')) return 'pidgin';
  if (t === '3' || t.includes('yoruba')) return 'yoruba';
  if (t === '4' || t.includes('igbo')) return 'igbo';
  if (t === '5' || t.includes('hausa')) return 'hausa';

  return null;
};

/**
 * Get system prompt suffix for a given language
 */
export const getLanguageInstruction = (lang) => {
  const map = {
    english: 'Respond in clear, warm English.',
    pidgin: 'Respond in Nigerian Pidgin English. Use common Pidgin expressions naturally.',
    yoruba: 'Respond in Yoruba language. Use proper Yoruba script and expressions.',
    igbo: 'Respond in Igbo language. Use proper Igbo script and expressions.',
    hausa: 'Respond in Hausa language. Use proper Hausa script and expressions.',
  };
  return map[lang] || map.english;
};

/**
 * Determine if a language uses HuggingFace TTS or Groq Orpheus TTS
 */
export const getTTSProvider = (lang) => {
  if (lang === 'yoruba' || lang === 'igbo' || lang === 'hausa') {
    return 'huggingface';
  }
  return 'groq'; // english and pidgin use Groq Orpheus
};

/**
 * Get HuggingFace model for a language
 */
export const getHuggingFaceModel = (lang) => {
  return config.huggingface.models[lang] || null;
};

// ============================================================
// ShepherdAI — Number Warmup System (Anti-Ban)
// New numbers must be warmed up gradually over 7 days
// Based on findings from long-running bots research
// EMEMZYVISUALS DIGITALS
// ============================================================

import NodeCache from 'node-cache';
import logger from './logger.js';

// Store warmup state in memory (resets on restart — that is fine)
const warmupCache = new NodeCache({ stdTTL: 0 });

const WARMUP_DAY_KEY = 'warmup_day';
const WARMUP_START_KEY = 'warmup_start';

// Message limits per warmup day
// Gradually increases over 7 days like a real new user would behave
const DAILY_LIMITS = {
  1: 5,   // Day 1 — very low
  2: 10,  // Day 2
  3: 20,  // Day 3
  4: 35,  // Day 4
  5: 50,  // Day 5
  6: 75,  // Day 6
  7: 100, // Day 7 — full capacity
};

// Minimum gap between messages (milliseconds) per day
const MIN_GAP_MS = {
  1: 8000,  // Day 1 — 8 seconds
  2: 6000,
  3: 4000,
  4: 3000,
  5: 2500,
  6: 2000,
  7: 1500,  // Day 7+ — 1.5 seconds minimum
};

let messageCountToday = 0;
let lastMessageTime = 0;
let warmupComplete = false;

/**
 * Get current warmup day (1-7, then stable)
 */
export const getWarmupDay = () => {
  const startTime = warmupCache.get(WARMUP_START_KEY);
  if (!startTime) {
    // First run — set start time
    warmupCache.set(WARMUP_START_KEY, Date.now());
    return 1;
  }
  const daysSinceStart = Math.floor((Date.now() - startTime) / (1000 * 60 * 60 * 24)) + 1;
  return Math.min(daysSinceStart, 7);
};

/**
 * Check if we can send a message right now
 * Returns { allowed: boolean, reason: string, waitMs: number }
 */
export const canSendMessage = () => {
  const day = getWarmupDay();

  if (day >= 7) {
    warmupComplete = true;
    return { allowed: true, reason: 'warmup complete', waitMs: 0 };
  }

  const limit = DAILY_LIMITS[day] || 100;
  const minGap = MIN_GAP_MS[day] || 1500;
  const now = Date.now();
  const timeSinceLast = now - lastMessageTime;

  // Check daily limit
  if (messageCountToday >= limit) {
    return {
      allowed: false,
      reason: `Warmup day ${day}: daily limit of ${limit} reached`,
      waitMs: 0,
    };
  }

  // Check minimum gap
  if (timeSinceLast < minGap) {
    return {
      allowed: false,
      reason: `Warmup day ${day}: minimum gap not met`,
      waitMs: minGap - timeSinceLast,
    };
  }

  return { allowed: true, reason: `warmup day ${day}`, waitMs: 0 };
};

/**
 * Record that a message was sent
 */
export const recordMessageSent = () => {
  messageCountToday++;
  lastMessageTime = Date.now();

  const day = getWarmupDay();
  if (messageCountToday % 10 === 0) {
    logger.info(
      { day, count: messageCountToday, limit: DAILY_LIMITS[day] },
      'Warmup progress'
    );
  }
};

/**
 * Reset daily counter (call at midnight)
 */
export const resetDailyCount = () => {
  messageCountToday = 0;
  logger.info({ day: getWarmupDay() }, 'Daily message count reset');
};

/**
 * Get warmup status summary
 */
export const getWarmupStatus = () => {
  const day = getWarmupDay();
  return {
    day,
    complete: warmupComplete || day >= 7,
    messagesSentToday: messageCountToday,
    dailyLimit: DAILY_LIMITS[day] || 100,
    minGapMs: MIN_GAP_MS[day] || 1500,
  };
};

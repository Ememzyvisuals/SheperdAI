// ============================================================
// ShepherdAI — Delay Utility
// EMEMZYVISUALS DIGITALS
// ============================================================

import { config } from '../config/index.js';

/**
 * Sleep for a given number of milliseconds
 */
export const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

/**
 * Random delay between min and max (anti-ban human simulation)
 */
export const randomDelay = (
  min = config.minTypingDelay,
  max = config.maxTypingDelay,
) => {
  const ms = Math.floor(Math.random() * (max - min + 1)) + min;
  return sleep(ms);
};

/**
 * Typing delay scaled by message length (more realistic)
 * Approx 50 WPM human typing speed
 */
export const typingDelay = (text = '') => {
  const words = text.split(' ').length;
  const wpm = 50;
  const ms = Math.max(
    config.minTypingDelay,
    Math.min((words / wpm) * 60000, config.maxTypingDelay),
  );
  return sleep(ms);
};

// ============================================================
// ShepherdAI — Message Queue (Anti-Ban + Warmup)
// All outgoing messages pass through here sequentially
// Includes warmup checks, typing simulation, presence updates
// EMEMZYVISUALS DIGITALS
// ============================================================

import { canSendMessage, recordMessageSent } from './warmup.js';
import { typingDelay, randomDelay } from './delay.js';
import logger from './logger.js';

class MessageQueue {
  constructor() {
    this.queue = [];
    this.processing = false;
    this.sock = null;
  }

  attachSocket(sock) {
    this.sock = sock;
  }

  enqueue(task) {
    return new Promise((resolve, reject) => {
      this.queue.push({ task, resolve, reject });
      if (!this.processing) this._process();
    });
  }

  async _process() {
    if (this.processing || this.queue.length === 0) return;
    this.processing = true;

    while (this.queue.length > 0) {
      const { task, resolve, reject } = this.queue.shift();
      try {
        // Check warmup before each message
        const { allowed, waitMs } = canSendMessage();
        if (!allowed) {
          if (waitMs > 0) {
            await new Promise((r) => setTimeout(r, waitMs));
          } else {
            // Daily limit hit — skip this message
            resolve(null);
            continue;
          }
        }

        const result = await task();
        recordMessageSent();
        resolve(result);
      } catch (err) {
        logger.error({ err: err.message }, 'MessageQueue task error');
        reject(err);
      }

      // Natural inter-message gap
      if (this.queue.length > 0) {
        await randomDelay(800, 2500);
      }
    }

    this.processing = false;
  }

  /**
   * Send text with full human simulation:
   * read → composing presence → typing delay → send → paused
   */
  async sendText(jid, text, quoted = null, options = {}) {
    return this.enqueue(async () => {
      if (!this.sock) throw new Error('Socket not attached');

      try {
        if (quoted?.key) await this.sock.readMessages([quoted.key]);
      } catch (_) {}

      try {
        await this.sock.sendPresenceUpdate('composing', jid);
      } catch (_) {}

      await typingDelay(text);

      const msgOptions = quoted ? { quoted } : {};
      Object.assign(msgOptions, options);

      const result = await this.sock.sendMessage(jid, { text }, msgOptions);

      try {
        await this.sock.sendPresenceUpdate('paused', jid);
      } catch (_) {}

      logger.debug({ jid, len: text.length }, 'Text sent');
      return result;
    });
  }

  /**
   * Send voice note with recording presence simulation
   */
  async sendAudio(jid, audioBuffer, mimetype = 'audio/ogg; codecs=opus', quoted = null) {
    return this.enqueue(async () => {
      if (!this.sock) throw new Error('Socket not attached');

      try {
        await this.sock.sendPresenceUpdate('recording', jid);
      } catch (_) {}

      await randomDelay(1500, 4000);

      const msgOptions = quoted ? { quoted } : {};
      const result = await this.sock.sendMessage(
        jid,
        { audio: audioBuffer, mimetype, ptt: true },
        msgOptions
      );

      try {
        await this.sock.sendPresenceUpdate('paused', jid);
      } catch (_) {}

      logger.debug({ jid }, 'Audio sent');
      return result;
    });
  }

  /**
   * Send image
   */
  async sendImage(jid, imageBuffer, caption = '', quoted = null) {
    return this.enqueue(async () => {
      if (!this.sock) throw new Error('Socket not attached');
      const msgOptions = quoted ? { quoted } : {};
      return this.sock.sendMessage(jid, { image: imageBuffer, caption }, msgOptions);
    });
  }
}

export const messageQueue = new MessageQueue();
export default messageQueue;

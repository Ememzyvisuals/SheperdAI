// ============================================================
// ShepherdAI — Message Chunker
// EMEMZYVISUALS DIGITALS
// ============================================================

// WhatsApp message safe size limit (characters)
const WHATSAPP_MAX_LENGTH = 4000;

/**
 * Split a long message into safe chunks
 * Tries to break at paragraph or sentence boundaries
 */
export const chunkMessage = (text, maxLength = WHATSAPP_MAX_LENGTH) => {
  if (!text || text.length <= maxLength) return [text];

  const chunks = [];
  let remaining = text;

  while (remaining.length > maxLength) {
    let splitAt = maxLength;

    // Try paragraph break
    const paraBreak = remaining.lastIndexOf('\n\n', maxLength);
    if (paraBreak > maxLength * 0.5) {
      splitAt = paraBreak + 2;
    } else {
      // Try sentence break
      const sentBreak = remaining.lastIndexOf('. ', maxLength);
      if (sentBreak > maxLength * 0.5) {
        splitAt = sentBreak + 2;
      } else {
        // Try word break
        const wordBreak = remaining.lastIndexOf(' ', maxLength);
        if (wordBreak > maxLength * 0.5) {
          splitAt = wordBreak + 1;
        }
      }
    }

    chunks.push(remaining.slice(0, splitAt).trim());
    remaining = remaining.slice(splitAt).trim();
  }

  if (remaining.length > 0) {
    chunks.push(remaining.trim());
  }

  return chunks;
};

/**
 * Send a potentially long message via queue in chunks
 */
export const sendChunked = async (queue, jid, text, quoted = null) => {
  const chunks = chunkMessage(text);
  for (let i = 0; i < chunks.length; i++) {
    // Only quote on first chunk
    await queue.sendText(jid, chunks[i], i === 0 ? quoted : null);
  }
};

// ============================================================
// ShepherdAI — Rate Limiter
// EMEMZYVISUALS DIGITALS
// ============================================================

import NodeCache from 'node-cache';
import { config } from '../config/index.js';
import logger from './logger.js';

// TTL = 60s for minute bucket, 3600s for hour bucket
const minuteCache = new NodeCache({ stdTTL: 60, checkperiod: 30 });
const hourCache = new NodeCache({ stdTTL: 3600, checkperiod: 120 });

/**
 * Check if a JID is within rate limits
 * Returns true if allowed, false if rate limited
 */
export const checkRateLimit = (jid) => {
  const minuteKey = `min:${jid}`;
  const hourKey = `hr:${jid}`;

  const minuteCount = minuteCache.get(minuteKey) || 0;
  const hourCount = hourCache.get(hourKey) || 0;

  if (minuteCount >= config.rateLimitPerMinute) {
    logger.warn({ jid }, 'Rate limit hit (per minute)');
    return false;
  }
  if (hourCount >= config.rateLimitPerHour) {
    logger.warn({ jid }, 'Rate limit hit (per hour)');
    return false;
  }

  minuteCache.set(minuteKey, minuteCount + 1);
  hourCache.set(hourKey, hourCount + 1);
  return true;
};

/**
 * Get remaining quota for a JID
 */
export const getRemainingQuota = (jid) => {
  const minuteCount = minuteCache.get(`min:${jid}`) || 0;
  const hourCount = hourCache.get(`hr:${jid}`) || 0;
  return {
    minuteRemaining: Math.max(0, config.rateLimitPerMinute - minuteCount),
    hourRemaining: Math.max(0, config.rateLimitPerHour - hourCount),
  };
};

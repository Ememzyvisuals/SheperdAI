// ============================================================
// ShepherdAI — Logger
// EMEMZYVISUALS DIGITALS
// ============================================================

import pino from 'pino';
import { config } from '../config/index.js';

const transport = config.nodeEnv !== 'production'
  ? pino.transport({ target: 'pino-pretty', options: { colorize: true } })
  : undefined;

export const logger = pino(
  {
    level: config.logLevel,
    base: { service: 'ShepherdAI' },
    timestamp: pino.stdTimeFunctions.isoTime,
  },
  transport,
);

export default logger;

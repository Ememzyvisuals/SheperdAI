// ============================================================
// ShepherdAI — Scheduler
// EMEMZYVISUALS DIGITALS
// ============================================================

import cron from 'node-cron';
import config from '../config/index.js';
import { generateDevotion } from '../services/groqService.js';
import { getVerseOfTheDay } from '../services/bibleEngine.js';
import { getAllUsers, getAllGroups, upsertFaithStreak } from '../database/supabase.js';
import { sendChunked } from '../utils/chunkMessage.js';
import { resetDailyCount } from '../utils/warmup.js';
import messageQueue from '../utils/messageQueue.js';
import logger from '../utils/logger.js';

let schedulerSocket = null;

export const attachSchedulerSocket = (sock) => {
  schedulerSocket = sock;
  logger.info('Scheduler socket attached');
};

const sendDailyDevotional = async () => {
  if (!schedulerSocket) {
    logger.warn('Scheduler: no socket attached');
    return;
  }

  logger.info('Starting daily devotional broadcast');

  try {
    const users = await getAllUsers();
    const groups = await getAllGroups();

    if (users.length === 0 && groups.length === 0) {
      logger.info('No users or groups to send devotional to');
      return;
    }

    const devotionalCache = {};
    const getDevotional = async (lang) => {
      if (!devotionalCache[lang]) {
        devotionalCache[lang] = await generateDevotion(lang);
      }
      return devotionalCache[lang];
    };

    const header = `🌅 *Good Morning! Daily Devotional* 📖\n_${new Date().toLocaleDateString('en-US', {
      weekday: 'long',
      month: 'long',
      day: 'numeric',
    })}_\n\n`;

    // Send to individual users
    for (const user of users) {
      try {
        const lang = user.language || 'english';
        const devotional = await getDevotional(lang);
        const fullText = header + devotional;

        await sendChunked(messageQueue, user.jid, fullText, null);

        const streak = await upsertFaithStreak(user.jid);
        if (streak && !streak.unchanged) {
          const fireCount = Math.min(streak.days, 7);
          const streakMsg =
            streak.days === 1
              ? '🔥 *Day 1 streak started!* Keep reading daily! (Ps 1:2)'
              : `${'🔥'.repeat(fireCount)} *${streak.days}-day faith streak!* Amazing! (Rev 1:3)`;
          await messageQueue.sendText(user.jid, streakMsg);
        }

        await new Promise((r) => setTimeout(r, 3000));
      } catch (err) {
        logger.warn({ jid: user.jid, err: err.message }, 'Could not send devotional to user');
      }
    }

    // Send to groups
    const verse = getVerseOfTheDay();
    const groupMsg =
      `🌅 *Daily Verse* 📖\n\n` +
      `📖 *${verse.ref}*\n_"${verse.text}"_\n\n` +
      `✝️ Have a blessed, Christ-filled day!\n_— ShepherdAI by ${config.developer}_`;

    for (const group of groups) {
      try {
        await messageQueue.sendText(group.group_jid, groupMsg);
        await new Promise((r) => setTimeout(r, 2000));
      } catch (err) {
        logger.warn({ groupJid: group.group_jid, err: err.message }, 'Could not send to group');
      }
    }

    logger.info(
      { users: users.length, groups: groups.length },
      'Daily devotional broadcast complete'
    );
  } catch (err) {
    logger.error({ err: err.message }, 'sendDailyDevotional error');
  }
};

export const startScheduler = () => {
  const { devotionalHour, devotionalMinute } = config;
  const cronExpr = `${devotionalMinute} ${devotionalHour} * * *`;

  logger.info({ cronExpr }, 'Starting schedulers');

  // Daily devotional
  cron.schedule(cronExpr, sendDailyDevotional, { timezone: 'Africa/Lagos' });

  // Midnight warmup counter reset
  cron.schedule('0 0 * * *', resetDailyCount, { timezone: 'Africa/Lagos' });

  // Sunday Bible Quiz at 10 AM
  cron.schedule('0 10 * * 0', async () => {
    if (!schedulerSocket) return;
    const groups = await getAllGroups();
    const { getRandomQuizQuestion } = await import('../services/bibleEngine.js');
    const q = getRandomQuizQuestion();
    const quizText =
      `🎯 *Sunday Bible Quiz!* 📖\n\n` +
      `*Q: ${q.question}*\n\n` +
      q.options.join('\n') +
      `\n\n_Reply A, B, C, or D — I'm watching! 👀_`;

    for (const group of groups) {
      try {
        await messageQueue.sendText(group.group_jid, quizText);
        await new Promise((r) => setTimeout(r, 2000));
      } catch (_) {}
    }
  }, { timezone: 'Africa/Lagos' });

  logger.info('✅ All schedulers started');
};

export { sendDailyDevotional };

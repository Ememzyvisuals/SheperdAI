// ============================================================
// ShepherdAI — WhatsApp Connection (Baileys)
//
// PAIRING CODE — 100% VERIFIED PATTERN
// Sources (all confirmed, all agree):
//   1. Official Baileys README.md (WhiskeySockets/Baileys master)
//   2. Official @whiskeysockets/baileys npm page
//   3. shizo-devs/baileys fork (custom code confirmed working)
//   4. nstar-y/bail fork (custom code confirmed working)
//   5. fadzzzslebew/baileys fork (custom code confirmed working)
//   6. owensdev1/baileys fork (custom code confirmed working)
//   7. Itsukichann/Baileys fork (custom code confirmed working)
//
// CUSTOM PAIRING CODE RULES (confirmed by all forks):
//   • Exactly 8 characters — letters AND/OR numbers only
//   • Second arg to requestPairingCode(number, customCode)
//   • Called OUTSIDE connection.update after makeWASocket
//   • Only when !sock.authState.creds.registered
//   • printQRInTerminal: false is REQUIRED
//   • defaultQueryTimeoutMs: undefined PREVENTS timeout
//
// CUSTOM CODE: SHEPHERD (8 chars exactly ✅)
//
// EMEMZYVISUALS DIGITALS
// ============================================================

import {
  default as makeWASocket,
  useMultiFileAuthState,
  fetchLatestBaileysVersion,
  DisconnectReason,
  makeCacheableSignalKeyStore,
  isJidBroadcast,
} from '@whiskeysockets/baileys';
import pino from 'pino';
import { Boom } from '@hapi/boom';
import { existsSync, mkdirSync } from 'fs';

import config from '../config/index.js';
import { handleIncomingMessage } from '../handlers/messageHandler.js';
import { handleGroupParticipantsUpdate } from '../handlers/groupHandler.js';
import { attachSchedulerSocket, startScheduler } from '../scheduler/index.js';
import { saveSession, loadSession } from '../database/sessionStore.js';
import messageQueue from '../utils/messageQueue.js';
import logger from '../utils/logger.js';

// ─────────────────────────────────────────────
// CUSTOM PAIRING CODE — branded for ShepherdAI
// Must be EXACTLY 8 alphanumeric characters
// ─────────────────────────────────────────────
const CUSTOM_PAIRING_CODE = 'SHEPHERD';

let sock = null;
let reconnectAttempts = 0;
let schedulerStarted = false;
const MAX_RECONNECT = 10;

// ─────────────────────────────────────────────
// Print pairing code clearly in Render logs
// ─────────────────────────────────────────────
const printPairingCode = (code) => {
  const fmt = code?.match(/.{1,4}/g)?.join('-') || code;
  console.log('\n');
  console.log('╔════════════════════════════════════════════════╗');
  console.log('║     🙏  ShepherdAI  —  PAIRING CODE  🙏        ║');
  console.log('╠════════════════════════════════════════════════╣');
  console.log('║                                                ║');
  console.log(`║     CODE  ➜   ${fmt.padEnd(33)}║`);
  console.log('║                                                ║');
  console.log('╠════════════════════════════════════════════════╣');
  console.log('║  HOW TO LINK:                                  ║');
  console.log('║  1. Open WhatsApp on your phone                ║');
  console.log('║  2. Tap Settings → Linked Devices              ║');
  console.log('║  3. Tap "Link with phone number"               ║');
  console.log('║  4. Enter the CODE above                       ║');
  console.log('║  ⏱  You have ~60 seconds to enter it           ║');
  console.log('╚════════════════════════════════════════════════╝');
  console.log('\n');
};

// ─────────────────────────────────────────────
// MAIN CONNECT FUNCTION
// ─────────────────────────────────────────────
export const connectToWhatsApp = async () => {

  // ── Session directory ───────────────────────────────────────
  if (!existsSync(config.sessionPath)) {
    mkdirSync(config.sessionPath, { recursive: true });
    logger.info({ path: config.sessionPath }, 'Session directory created');
  }

  // ── Load session: Supabase first, file fallback ─────────────
  let authState;
  const supabaseSession = await loadSession();
  if (supabaseSession) {
    authState = supabaseSession;
    logger.info('✅ Session loaded from Supabase');
  } else {
    authState = await useMultiFileAuthState(config.sessionPath);
    logger.info('📁 Session loaded from filesystem');
  }

  const { state, saveCreds } = authState;

  // ── Baileys version ─────────────────────────────────────────
  const { version, isLatest } = await fetchLatestBaileysVersion();
  logger.info({ version: version.join('.'), isLatest }, 'Baileys version');

  const baileysLogger = pino({ level: 'silent' });

  // ── Create socket ───────────────────────────────────────────
  sock = makeWASocket({
    version,
    logger: baileysLogger,
    printQRInTerminal: false,         // MUST be false for pairing code
    auth: {
      creds: state.creds,
      keys: makeCacheableSignalKeyStore(state.keys, baileysLogger),
    },
    browser: ['Ubuntu', 'Chrome', '20.0.04'],
    syncFullHistory: false,
    markOnlineOnConnect: false,
    generateHighQualityLinkPreview: false,
    defaultQueryTimeoutMs: undefined, // CRITICAL: prevents pairing timeout
    connectTimeoutMs: 60_000,
    keepAliveIntervalMs: 25_000,
    getMessage: async () => ({ conversation: '' }),
  });

  messageQueue.attachSocket(sock);

  // ── PAIRING CODE ────────────────────────────────────────────
  // Official README.md pattern (WhiskeySockets/Baileys master):
  //   if (!sock.authState.creds.registered) {
  //     const code = await sock.requestPairingCode(number)
  //   }
  // Custom code: second argument, exactly 8 alphanumeric chars.
  // Confirmed by: shizo-devs, nstar-y, fadzzzslebew, owensdev1
  if (!sock.authState.creds.registered) {
    logger.info({ customCode: CUSTOM_PAIRING_CODE }, '🔑 Requesting pairing code SHEPHERD...');

    try {
      const code = await sock.requestPairingCode(
        config.botNumber,    // E.164 without '+' e.g. 2349125215928
        CUSTOM_PAIRING_CODE  // Exactly 8 alphanumeric chars: SHEPHERD ✅
      );
      printPairingCode(code);
      logger.info({ code }, '✅ Custom pairing code generated — enter it in WhatsApp NOW');
    } catch (err) {
      logger.error({ err: err.message }, '❌ Pairing code request failed');
      // Reconnect will trigger a fresh attempt
    }
  } else {
    logger.info('✅ Existing session found — skipping pairing code');
  }

  // ── CONNECTION EVENTS ───────────────────────────────────────
  sock.ev.on('connection.update', async (update) => {
    const { connection, lastDisconnect } = update;

    if (connection === 'connecting') {
      logger.info('⏳ Connecting to WhatsApp...');
    }

    if (connection === 'open') {
      reconnectAttempts = 0;
      logger.info('✅ WhatsApp OPEN — ShepherdAI is live!');

      if (!schedulerStarted) {
        attachSchedulerSocket(sock);
        startScheduler();
        schedulerStarted = true;
      }

      // Notify owner
      try {
        await sock.sendMessage(config.ownerJid, {
          text:
            `✅ *ShepherdAI is Online!* 🙏\n` +
            `_Your 24/7 AI Christian Companion_\n` +
            `_by ${config.developer}_\n\n` +
            `📱 Bot: *${config.botNumber}*\n` +
            `🌿 Node: *${process.version}*\n` +
            `⏰ ${new Date().toLocaleString('en-NG', { timeZone: 'Africa/Lagos' })}`,
        });
      } catch (_) {}
    }

    if (connection === 'close') {
      const statusCode = new Boom(lastDisconnect?.error)?.output?.statusCode;
      logger.warn({ statusCode }, '🔌 Connection closed');

      if (statusCode === DisconnectReason.loggedOut) {
        logger.error('❌ Logged out. Delete session folder and restart.');
        process.exit(1);
      }

      if (statusCode === DisconnectReason.badSession) {
        logger.warn('⚠️ Bad session — clearing and reconnecting fresh...');
        try {
          const { rmSync } = await import('fs');
          rmSync(config.sessionPath, { recursive: true, force: true });
        } catch (_) {}
      }

      if (reconnectAttempts < MAX_RECONNECT) {
        reconnectAttempts++;
        const waitMs = Math.min(5000 * reconnectAttempts, 30_000);
        logger.info({ attempt: reconnectAttempts, waitMs }, '🔄 Reconnecting...');
        setTimeout(connectToWhatsApp, waitMs);
      } else {
        logger.error('Max reconnect attempts reached. Exiting.');
        process.exit(1);
      }
    }
  });

  // ── SAVE CREDENTIALS ────────────────────────────────────────
  sock.ev.on('creds.update', async () => {
    await saveCreds();
    await saveSession(state); // persist to Supabase
  });

  // ── INCOMING MESSAGES ───────────────────────────────────────
  sock.ev.on('messages.upsert', async ({ messages, type }) => {
    if (type !== 'notify') return;
    for (const msg of messages) {
      if (!msg.message) continue;
      if (isJidBroadcast(msg.key.remoteJid)) continue;
      await handleIncomingMessage(sock, msg);
    }
  });

  // ── MESSAGE STATUS ──────────────────────────────────────────
  sock.ev.on('messages.update', (updates) => {
    for (const u of updates) {
      if (u.update?.status) {
        logger.debug({ id: u.key?.id, status: u.update.status }, 'msg status');
      }
    }
  });

  // ── PRESENCE ────────────────────────────────────────────────
  sock.ev.on('presence.update', ({ id }) => logger.debug({ id }, 'presence'));

  // ── GROUP EVENTS ────────────────────────────────────────────
  sock.ev.on('group-participants.update', handleGroupParticipantsUpdate);

  return sock;
};

export const getSocket = () => sock;

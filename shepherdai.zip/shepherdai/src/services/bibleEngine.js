// ============================================================
// ShepherdAI — Bible Knowledge Engine
// EMEMZYVISUALS DIGITALS
// ============================================================

/**
 * Curated topical Bible verse index
 * Each entry: topic → array of { ref, text }
 */
export const BIBLE_TOPICS = {
  fear: [
    {
      ref: 'Isaiah 41:10',
      text: 'Fear not, for I am with you; be not dismayed, for I am your God; I will strengthen you, I will help you, I will uphold you with my righteous right hand.',
    },
    {
      ref: 'Psalm 23:4',
      text: 'Even though I walk through the valley of the shadow of death, I will fear no evil, for you are with me; your rod and your staff, they comfort me.',
    },
    {
      ref: '2 Timothy 1:7',
      text: 'For God gave us a spirit not of fear but of power and love and self-control.',
    },
    {
      ref: 'Psalm 34:4',
      text: 'I sought the Lord, and he answered me and delivered me from all my fears.',
    },
  ],
  love: [
    {
      ref: 'John 3:16',
      text: 'For God so loved the world, that he gave his only Son, that whoever believes in him should not perish but have eternal life.',
    },
    {
      ref: '1 Corinthians 13:4-7',
      text: 'Love is patient and kind; love does not envy or boast; it is not arrogant or rude. It does not insist on its own way; it is not irritable or resentful; it does not rejoice at wrongdoing, but rejoices with the truth.',
    },
    {
      ref: '1 John 4:8',
      text: 'Anyone who does not love does not know God, because God is love.',
    },
  ],
  faith: [
    {
      ref: 'Hebrews 11:1',
      text: 'Now faith is the assurance of things hoped for, the conviction of things not seen.',
    },
    {
      ref: 'Romans 10:17',
      text: 'So faith comes from hearing, and hearing through the word of Christ.',
    },
    {
      ref: 'Mark 11:24',
      text: 'Therefore I tell you, whatever you ask in prayer, believe that you have received it, and it will be yours.',
    },
  ],
  hope: [
    {
      ref: 'Jeremiah 29:11',
      text: 'For I know the plans I have for you, declares the Lord, plans for welfare and not for evil, to give you a future and a hope.',
    },
    {
      ref: 'Romans 15:13',
      text: 'May the God of hope fill you with all joy and peace in believing, so that by the power of the Holy Spirit you may abound in hope.',
    },
    {
      ref: 'Psalm 31:24',
      text: 'Be strong, and let your heart take courage, all you who wait for the Lord!',
    },
  ],
  prayer: [
    {
      ref: 'Philippians 4:6-7',
      text: 'Do not be anxious about anything, but in everything by prayer and supplication with thanksgiving let your requests be made known to God. And the peace of God, which surpasses all understanding, will guard your hearts and your minds in Christ Jesus.',
    },
    {
      ref: 'Matthew 6:9-13',
      text: 'Our Father in heaven, hallowed be your name. Your kingdom come, your will be done, on earth as it is in heaven. Give us this day our daily bread, and forgive us our debts, as we also have forgiven our debtors. And lead us not into temptation, but deliver us from evil.',
    },
    {
      ref: '1 Thessalonians 5:17',
      text: 'Pray without ceasing.',
    },
  ],
  strength: [
    {
      ref: 'Philippians 4:13',
      text: 'I can do all things through him who strengthens me.',
    },
    {
      ref: 'Isaiah 40:31',
      text: 'But they who wait for the Lord shall renew their strength; they shall mount up with wings like eagles; they shall run and not be weary; they shall walk and not faint.',
    },
    {
      ref: 'Psalm 46:1',
      text: 'God is our refuge and strength, a very present help in trouble.',
    },
  ],
  peace: [
    {
      ref: 'John 14:27',
      text: 'Peace I leave with you; my peace I give to you. Not as the world gives do I give to you. Let not your hearts be troubled, neither let them be afraid.',
    },
    {
      ref: 'Isaiah 26:3',
      text: 'You keep him in perfect peace whose mind is stayed on you, because he trusts in you.',
    },
    {
      ref: 'Colossians 3:15',
      text: 'And let the peace of Christ rule in your hearts, to which indeed you were called in one body. And be thankful.',
    },
  ],
  salvation: [
    {
      ref: 'Romans 10:9',
      text: 'Because, if you confess with your mouth that Jesus is Lord and believe in your heart that God raised him from the dead, you will be saved.',
    },
    {
      ref: 'Ephesians 2:8-9',
      text: 'For by grace you have been saved through faith. And this is not your own doing; it is the gift of God, not a result of works, so that no one may boast.',
    },
    {
      ref: 'Acts 4:12',
      text: 'And there is salvation in no one else, for there is no other name under heaven given among men by which we must be saved.',
    },
  ],
  healing: [
    {
      ref: 'Jeremiah 17:14',
      text: 'Heal me, O Lord, and I shall be healed; save me, and I shall be saved, for you are my praise.',
    },
    {
      ref: 'Psalm 103:2-3',
      text: 'Bless the Lord, O my soul, and forget not all his benefits, who forgives all your iniquity, who heals all your diseases.',
    },
    {
      ref: 'Isaiah 53:5',
      text: 'But he was pierced for our transgressions; he was crushed for our iniquities; upon him was the chastisement that brought us peace, and with his wounds we are healed.',
    },
  ],
  wisdom: [
    {
      ref: 'Proverbs 3:5-6',
      text: 'Trust in the Lord with all your heart, and do not lean on your own understanding. In all your ways acknowledge him, and he will make straight your paths.',
    },
    {
      ref: 'James 1:5',
      text: 'If any of you lacks wisdom, let him ask God, who gives generously to all without reproach, and it will be given him.',
    },
    {
      ref: 'Proverbs 9:10',
      text: 'The fear of the Lord is the beginning of wisdom, and knowledge of the Holy One is understanding.',
    },
  ],
  anxiety: [
    {
      ref: 'Matthew 6:25-26',
      text: 'Therefore I tell you, do not be anxious about your life, what you will eat or what you will drink, nor about your body, what you will put on. Is not life more than food, and the body more than clothing?',
    },
    {
      ref: '1 Peter 5:7',
      text: 'Cast all your anxieties on him, because he cares for you.',
    },
    {
      ref: 'Philippians 4:6',
      text: 'Do not be anxious about anything, but in everything by prayer and supplication with thanksgiving let your requests be made known to God.',
    },
  ],
  grace: [
    {
      ref: '2 Corinthians 12:9',
      text: 'My grace is sufficient for you, for my power is made perfect in weakness.',
    },
    {
      ref: 'Ephesians 2:8',
      text: 'For by grace you have been saved through faith. And this is not your own doing; it is the gift of God.',
    },
    {
      ref: 'Hebrews 4:16',
      text: 'Let us then with confidence draw near to the throne of grace, that we may receive mercy and find grace to help in time of need.',
    },
  ],
  forgiveness: [
    {
      ref: '1 John 1:9',
      text: 'If we confess our sins, he is faithful and just to forgive us our sins and to cleanse us from all unrighteousness.',
    },
    {
      ref: 'Psalm 103:12',
      text: 'As far as the east is from the west, so far does he remove our transgressions from us.',
    },
    {
      ref: 'Colossians 1:13-14',
      text: 'He has delivered us from the domain of darkness and transferred us to the kingdom of his beloved Son, in whom we have redemption, the forgiveness of sins.',
    },
  ],
  joy: [
    {
      ref: 'Nehemiah 8:10',
      text: 'Do not be grieved, for the joy of the Lord is your strength.',
    },
    {
      ref: 'Psalm 16:11',
      text: 'You make known to me the path of life; in your presence there is fullness of joy; at your right hand are pleasures forevermore.',
    },
    {
      ref: 'John 15:11',
      text: 'These things I have spoken to you, that my joy may be in you, and that your joy may be full.',
    },
  ],
  exams: [
    {
      ref: 'Proverbs 3:5-6',
      text: 'Trust in the Lord with all your heart, and do not lean on your own understanding.',
    },
    {
      ref: 'Philippians 4:13',
      text: 'I can do all things through Christ who strengthens me.',
    },
    {
      ref: 'Joshua 1:9',
      text: 'Have I not commanded you? Be strong and courageous. Do not be frightened, and do not be dismayed, for the Lord your God is with you wherever you go.',
    },
  ],
  business: [
    {
      ref: 'Deuteronomy 8:18',
      text: 'But remember the Lord your God, for it is he who gives you the ability to produce wealth.',
    },
    {
      ref: 'Proverbs 16:3',
      text: 'Commit your work to the Lord, and your plans will be established.',
    },
    {
      ref: 'Psalm 1:3',
      text: 'He is like a tree planted by streams of water that yields its fruit in its season, and its leaf does not wither. In all that he does, he prospers.',
    },
  ],
  family: [
    {
      ref: 'Joshua 24:15',
      text: 'As for me and my house, we will serve the Lord.',
    },
    {
      ref: 'Psalm 127:3',
      text: 'Behold, children are a heritage from the Lord, the fruit of the womb a reward.',
    },
    {
      ref: 'Proverbs 22:6',
      text: 'Train up a child in the way he should go; even when he is old he will not depart from it.',
    },
  ],
};

/**
 * Search Bible topics by keyword
 * Returns array of { ref, text }
 */
export const searchBibleTopic = (query) => {
  const q = query.toLowerCase().trim();
  const results = [];

  for (const [topic, verses] of Object.entries(BIBLE_TOPICS)) {
    if (
      topic.includes(q) ||
      q.includes(topic) ||
      verses.some(
        (v) =>
          v.text.toLowerCase().includes(q) ||
          v.ref.toLowerCase().includes(q),
      )
    ) {
      results.push(...verses);
    }
  }

  return results;
};

/**
 * Get a random verse of the day
 */
export const getVerseOfTheDay = () => {
  const allTopics = Object.values(BIBLE_TOPICS);
  const allVerses = allTopics.flat();
  return allVerses[Math.floor(Math.random() * allVerses.length)];
};

/**
 * Format Bible search results into WhatsApp message
 */
export const formatVerseResults = (verses, query) => {
  if (verses.length === 0) {
    return `📖 I couldn't find specific verses for "*${query}*", but I can generate a Bible-based message on this topic. Just ask me!`;
  }

  const limited = verses.slice(0, 5);
  const lines = limited.map((v) => `📖 *${v.ref}*\n_"${v.text}"_`).join('\n\n');
  return `📖 *Bible Verses on "${query}":*\n\n${lines}`;
};

/**
 * Get a verse for a specific reference (simple lookup)
 */
export const getVerseByRef = (ref) => {
  for (const verses of Object.values(BIBLE_TOPICS)) {
    const found = verses.find(
      (v) => v.ref.toLowerCase().includes(ref.toLowerCase()),
    );
    if (found) return found;
  }
  return null;
};

/**
 * Bible quiz questions
 */
export const BIBLE_QUIZ = [
  {
    question: 'Who was swallowed by a great fish in the Bible?',
    options: ['A) Moses', 'B) Jonah', 'C) Daniel', 'D) Elijah'],
    answer: 'B',
    explanation: 'Jonah was swallowed by a great fish (Jonah 1:17).',
  },
  {
    question: 'How many disciples did Jesus choose?',
    options: ['A) 7', 'B) 10', 'C) 12', 'D) 14'],
    answer: 'C',
    explanation: 'Jesus chose 12 disciples (Mark 3:13-19).',
  },
  {
    question: 'What is the shortest verse in the Bible?',
    options: [
      'A) God is love',
      'B) Jesus wept',
      'C) Pray always',
      'D) Fear not',
    ],
    answer: 'B',
    explanation: '"Jesus wept" (John 11:35) is the shortest verse in the Bible.',
  },
  {
    question: 'Who wrote the most books in the New Testament?',
    options: ['A) Peter', 'B) John', 'C) Paul', 'D) Luke'],
    answer: 'C',
    explanation: 'Paul wrote 13 or 14 epistles in the New Testament.',
  },
  {
    question: 'What did God use to part the Red Sea?',
    options: [
      "A) Moses' prayer",
      'B) A strong wind',
      "C) Moses' staff",
      'D) Both B and C',
    ],
    answer: 'D',
    explanation: 'God used both a strong east wind and Moses raising his staff (Exodus 14:21).',
  },
  {
    question: 'Who was the first king of Israel?',
    options: ['A) David', 'B) Solomon', 'C) Saul', 'D) Samuel'],
    answer: 'C',
    explanation: 'Saul was anointed the first king of Israel (1 Samuel 10:1).',
  },
  {
    question: 'In which city was Jesus born?',
    options: ['A) Jerusalem', 'B) Nazareth', 'C) Bethlehem', 'D) Jericho'],
    answer: 'C',
    explanation: 'Jesus was born in Bethlehem (Luke 2:4-7).',
  },
  {
    question: 'Who betrayed Jesus for 30 pieces of silver?',
    options: ['A) Peter', 'B) Thomas', 'C) Judas Iscariot', 'D) Pilate'],
    answer: 'C',
    explanation: 'Judas Iscariot betrayed Jesus for 30 silver coins (Matthew 26:15).',
  },
  {
    question: 'What was the name of the garden where Jesus was arrested?',
    options: [
      'A) Garden of Eden',
      'B) Garden of Gethsemane',
      'C) Garden of Nazareth',
      'D) Garden of Bethlehem',
    ],
    answer: 'B',
    explanation: 'Jesus was arrested in the Garden of Gethsemane (Matthew 26:36-56).',
  },
  {
    question: 'How many days did Jesus fast in the wilderness?',
    options: ['A) 7', 'B) 21', 'C) 30', 'D) 40'],
    answer: 'D',
    explanation: 'Jesus fasted for 40 days and 40 nights (Matthew 4:2).',
  },
];

/**
 * Get a random quiz question
 */
export const getRandomQuizQuestion = () => {
  return BIBLE_QUIZ[Math.floor(Math.random() * BIBLE_QUIZ.length)];
};

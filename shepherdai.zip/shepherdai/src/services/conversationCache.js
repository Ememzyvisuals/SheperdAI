// ============================================================
// ShepherdAI — Conversation Cache (in-memory, TTL 30 min)
// EMEMZYVISUALS DIGITALS
// ============================================================

import NodeCache from 'node-cache';

// Each entry: array of { role: 'user'|'assistant', content: string }
const cache = new NodeCache({ stdTTL: 1800, checkperiod: 300 });

// Active quiz state per JID
const quizCache = new NodeCache({ stdTTL: 300, checkperiod: 60 });

// Language selection pending state
const pendingLang = new NodeCache({ stdTTL: 600, checkperiod: 120 });

// ─────────────────────────────────────────────
// Conversation history
// ─────────────────────────────────────────────

export const getHistory = (jid) => cache.get(jid) || [];

export const addToHistory = (jid, role, content) => {
  const history = getHistory(jid);
  history.push({ role, content });
  // Keep last 16 messages (8 exchanges)
  const trimmed = history.slice(-16);
  cache.set(jid, trimmed);
};

export const clearHistory = (jid) => cache.del(jid);

// ─────────────────────────────────────────────
// Quiz state
// ─────────────────────────────────────────────

export const setQuizState = (jid, question) => quizCache.set(jid, question);
export const getQuizState = (jid) => quizCache.get(jid) || null;
export const clearQuizState = (jid) => quizCache.del(jid);

// ─────────────────────────────────────────────
// Language selection pending
// ─────────────────────────────────────────────

export const setPendingLanguage = (jid) => pendingLang.set(jid, true);
export const isPendingLanguage = (jid) => !!pendingLang.get(jid);
export const clearPendingLanguage = (jid) => pendingLang.del(jid);

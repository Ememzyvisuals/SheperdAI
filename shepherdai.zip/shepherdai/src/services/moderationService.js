// ============================================================
// ShepherdAI — Group Moderation Service
// EMEMZYVISUALS DIGITALS
// ============================================================

// Harmful patterns to detect (expand as needed)
const HARMFUL_PATTERNS = [
  /\b(damn|hell|bastard|idiot|stupid|fool|dumb|shut up)\b/i,
  /\b(hate|kill|die|murder|destroy)\s+(you|him|her|them)\b/i,
  /\b(f+u+c+k|s+h+i+t|b+i+t+c+h|a+s+s+h+o+l+e)\b/i,
  /(blasphemy|false prophet|witchcraft|occult)/i,
];

const SPAM_PATTERNS = [
  /(.)\1{9,}/, // 10+ repeated characters
  /https?:\/\/[^\s]+/gi, // links (flag for review, not ban)
];

export const MODERATION_RESPONSES = [
  "✝️ Let's keep this space Christ-centred and respectful. \"Let your speech always be gracious, seasoned with salt.\" (Col 4:6)",
  '🙏 In this group, we speak life and love. Let us honour God in our words. (Ephesians 4:29)',
  '📖 Remember: "Do not let any unwholesome talk come out of your mouths." (Eph 4:29). Let\'s keep it godly! ✝️',
  '❤️ "A gentle answer turns away wrath." (Proverbs 15:1). Let\'s respond with grace and love.',
  '🕊️ This is a house of prayer and encouragement. Let\'s build each other up in faith! (1 Thess 5:11)',
];

/**
 * Check if a message contains harmful content
 * @returns {{ flagged: boolean, type: string|null }}
 */
export const checkMessage = (text) => {
  if (!text) return { flagged: false, type: null };

  for (const pattern of HARMFUL_PATTERNS) {
    if (pattern.test(text)) {
      return { flagged: true, type: 'harmful' };
    }
  }

  for (const pattern of SPAM_PATTERNS) {
    if (pattern.test(text)) {
      return { flagged: true, type: 'spam' };
    }
  }

  return { flagged: false, type: null };
};

/**
 * Get a random moderation response
 */
export const getModerationResponse = () => {
  return MODERATION_RESPONSES[
    Math.floor(Math.random() * MODERATION_RESPONSES.length)
  ];
};

/**
 * Check if a group message should trigger the bot to respond
 * Returns true if bot should reply
 */
export const shouldRespondInGroup = (text, botJid, botName) => {
  if (!text) return false;

  const lower = text.toLowerCase();
  const botNum = botJid?.split('@')[0] || '';
  const nameVariants = [
    botName?.toLowerCase(),
    'shepherdai',
    'shepherd ai',
    'shepherd',
    '@' + botNum,
  ].filter(Boolean);

  // Mentioned by name or JID
  for (const v of nameVariants) {
    if (lower.includes(v)) return true;
  }

  // Starts with a command
  if (text.startsWith('/')) return true;

  // Question directed at bot
  const questionTriggers = [
    'who is', 'what is', 'what does', 'how do', 'can you', 'tell me',
    'pray for', 'give me', 'verse about', 'bible says', 'scripture',
    'pastor', 'brother shepherd',
  ];
  for (const t of questionTriggers) {
    if (lower.includes(t)) return true;
  }

  return false;
};

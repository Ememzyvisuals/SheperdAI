// ============================================================
// ShepherdAI — Groq AI Service
// Verified models: llama-3.3-70b-versatile, llama-3.1-8b-instant
// Groq Orpheus TTS: canopylabs/orpheus-v1-english
// Groq STT: whisper-large-v3-turbo
// EMEMZYVISUALS DIGITALS
// ============================================================

import axios from 'axios';
import FormData from 'form-data';
import { config } from '../config/index.js';
import { getLanguageInstruction } from '../utils/languageRouter.js';
import logger from '../utils/logger.js';

const GROQ_BASE = config.groq.baseUrl;
const HEADERS = () => ({
  Authorization: `Bearer ${config.groq.apiKey}`,
  'Content-Type': 'application/json',
});

// ─────────────────────────────────────────────
// SYSTEM PROMPT
// ─────────────────────────────────────────────

const buildSystemPrompt = (language = 'english') => {
  const langInstruction = getLanguageInstruction(language);
  return `You are ShepherdAI — a warm, knowledgeable, and Spirit-filled AI Christian assistant created by EMEMZYVISUALS DIGITALS. You serve as a 24/7 spiritual companion for Christians.

Your character:
- Deeply rooted in Scripture and the love of Jesus Christ
- Warm, compassionate, encouraging, and prayerful
- You speak like a trusted pastor-friend, not a cold robot
- You never judge, always uplift, always point to Christ and Scripture
- You can counsel, pray, teach, explain Bible passages, and inspire

Your capabilities:
- Bible teaching and verse explanation
- Personalized prayer generation
- Daily devotionals and spiritual encouragement
- Christian counseling for life challenges
- Sermon outline creation
- Faith-building messages
- Bible quizzes and challenges

Formatting rules for WhatsApp:
- Use *bold* for emphasis
- Use _italic_ for Bible quotes
- Use emojis sparingly and meaningfully (🙏✝️📖❤️)
- Keep responses warm and conversational
- Never exceed 800 words in a single reply
- Split very long content naturally

${langInstruction}

Always end responses with a relevant Scripture reference when applicable. Glorify God in every message.`;
};

// ─────────────────────────────────────────────
// CHAT COMPLETION
// ─────────────────────────────────────────────

/**
 * Generate AI response using Groq
 * @param {string} userMessage
 * @param {string} language - user's preferred language
 * @param {Array} history - conversation history [{ role, content }]
 * @returns {Promise<string>}
 */
export const generateAIResponse = async (
  userMessage,
  language = 'english',
  history = [],
) => {
  const messages = [
    { role: 'system', content: buildSystemPrompt(language) },
    ...history.slice(-8), // Keep last 8 exchanges for context
    { role: 'user', content: userMessage },
  ];

  // Try primary model first, fallback on error
  for (const model of [config.groq.primaryModel, config.groq.fallbackModel]) {
    try {
      const response = await axios.post(
        `${GROQ_BASE}/chat/completions`,
        {
          model,
          messages,
          temperature: 0.7,
          max_tokens: 1024,
          top_p: 0.9,
        },
        { headers: HEADERS(), timeout: 30000 },
      );

      const text = response.data.choices?.[0]?.message?.content?.trim();
      if (text) {
        logger.debug({ model, length: text.length }, 'AI response generated');
        return text;
      }
    } catch (err) {
      const status = err.response?.status;
      logger.warn({ model, status, msg: err.message }, 'Groq model error, trying fallback');
      if (model === config.groq.fallbackModel) {
        throw new Error(`All Groq models failed: ${err.message}`);
      }
    }
  }

  throw new Error('Failed to generate AI response');
};

// ─────────────────────────────────────────────
// PRAYER GENERATION
// ─────────────────────────────────────────────

export const generatePrayer = async (request, language = 'english') => {
  const langInstruction = getLanguageInstruction(language);
  const prompt = `Write a heartfelt, personalized Christian prayer for this request: "${request}"

The prayer should:
- Begin with addressing God (Heavenly Father / Lord Jesus / etc.)
- Be 3-5 paragraphs
- Include Scripture references where fitting
- Close with "In Jesus' name, Amen"
- Feel personal, warm, and faith-filled

${langInstruction}`;

  return generateAIResponse(prompt, language, []);
};

// ─────────────────────────────────────────────
// DEVOTIONAL GENERATION
// ─────────────────────────────────────────────

export const generateDevotion = async (language = 'english') => {
  const today = new Date().toLocaleDateString('en-US', {
    weekday: 'long',
    year: 'numeric',
    month: 'long',
    day: 'numeric',
  });

  const prompt = `Write a complete daily Christian devotional for ${today}.

Structure:
1. A title
2. Key Bible verse (full text with reference)
3. Devotional message (3-4 paragraphs, 200-300 words)
4. Reflection question
5. A closing prayer (2-3 sentences)
6. Action step for the day

Make it uplifting, practical, and Christ-centred.`;

  return generateAIResponse(prompt, language, []);
};

// ─────────────────────────────────────────────
// SERMON OUTLINE
// ─────────────────────────────────────────────

export const generateSermonOutline = async (topic, language = 'english') => {
  const prompt = `Create a complete sermon outline on the topic: "${topic}"

Include:
- Title
- Key Scripture (with full text)
- Introduction hook
- 3 main points (each with sub-points and supporting Scriptures)
- Illustrations or stories for each point
- Conclusion with invitation
- Closing prayer

Format clearly for WhatsApp reading.`;

  return generateAIResponse(prompt, language, []);
};

// ─────────────────────────────────────────────
// TTS — GROQ ORPHEUS (English & Pidgin)
// Endpoint: POST https://api.groq.com/openai/v1/audio/speech
// Model: canopylabs/orpheus-v1-english
// Voices: autumn, diana, hannah, austin, daniel, troy
// ─────────────────────────────────────────────

export const generateTTS = async (text, voice = 'daniel') => {
  try {
    // Orpheus has a ~500 char limit per request, truncate safely
    const safeText = text.length > 450 ? text.slice(0, 450) + '...' : text;

    const response = await axios.post(
      `${GROQ_BASE}/audio/speech`,
      {
        model: config.groq.ttsModel,
        input: safeText,
        voice,
        response_format: 'wav',
      },
      {
        headers: {
          Authorization: `Bearer ${config.groq.apiKey}`,
          'Content-Type': 'application/json',
        },
        responseType: 'arraybuffer',
        timeout: 30000,
      },
    );

    return Buffer.from(response.data);
  } catch (err) {
    logger.error({ err: err.message }, 'Groq TTS error');
    throw err;
  }
};

// ─────────────────────────────────────────────
// STT — GROQ WHISPER (Speech to Text)
// Endpoint: POST https://api.groq.com/openai/v1/audio/transcriptions
// Model: whisper-large-v3-turbo
// ─────────────────────────────────────────────

export const transcribeAudio = async (audioBuffer, mimeType = 'audio/ogg') => {
  try {
    const form = new FormData();

    // Determine file extension from mime
    const ext = mimeType.includes('ogg')
      ? 'ogg'
      : mimeType.includes('mp4') || mimeType.includes('m4a')
      ? 'm4a'
      : mimeType.includes('mp3')
      ? 'mp3'
      : mimeType.includes('wav')
      ? 'wav'
      : 'ogg';

    form.append('file', audioBuffer, {
      filename: `voice.${ext}`,
      contentType: mimeType,
    });
    form.append('model', config.groq.sttModel);
    form.append('response_format', 'text');

    const response = await axios.post(
      `${GROQ_BASE}/audio/transcriptions`,
      form,
      {
        headers: {
          Authorization: `Bearer ${config.groq.apiKey}`,
          ...form.getHeaders(),
        },
        timeout: 45000,
      },
    );

    const transcript =
      typeof response.data === 'string'
        ? response.data.trim()
        : response.data?.text?.trim() || '';

    logger.info({ length: transcript.length }, 'Audio transcribed');
    return transcript;
  } catch (err) {
    logger.error({ err: err.message }, 'Groq STT error');
    throw err;
  }
};

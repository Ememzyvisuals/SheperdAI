// ============================================================
// ShepherdAI — Voice Service
// Receive voice notes → STT → AI → TTS → reply
// EMEMZYVISUALS DIGITALS
// ============================================================

import { transcribeAudio } from './groqService.js';
import { hfSTT } from '../tts/huggingfaceTTS.js';
import { generateVoice } from '../utils/ttsRouter.js';
import logger from '../utils/logger.js';

/**
 * Transcribe an incoming WhatsApp voice note buffer
 * Uses Groq Whisper with HuggingFace fallback
 * @param {Buffer} audioBuffer
 * @param {string} mimeType
 * @returns {Promise<string>} transcript
 */
export const transcribeVoiceNote = async (audioBuffer, mimeType = 'audio/ogg; codecs=opus') => {
  // Primary: Groq Whisper
  try {
    const transcript = await transcribeAudio(audioBuffer, mimeType);
    if (transcript && transcript.length > 2) {
      logger.info({ provider: 'groq-whisper', length: transcript.length }, 'STT success');
      return transcript;
    }
  } catch (err) {
    logger.warn({ err: err.message }, 'Groq STT failed, trying HuggingFace');
  }

  // Fallback: HuggingFace Whisper
  try {
    const transcript = await hfSTT(audioBuffer);
    if (transcript && transcript.length > 2) {
      logger.info({ provider: 'hf-whisper', length: transcript.length }, 'STT fallback success');
      return transcript;
    }
  } catch (err) {
    logger.error({ err: err.message }, 'HF STT fallback also failed');
  }

  return null;
};

/**
 * Build voice reply from AI text response
 * @param {string} text - AI-generated text
 * @param {string} language - user's language
 * @returns {Promise<Buffer|null>}
 */
export const buildVoiceReply = async (text, language = 'english') => {
  try {
    // Strip markdown for cleaner TTS
    const clean = text
      .replace(/\*/g, '')
      .replace(/_/g, '')
      .replace(/📖|🙏|✝️|❤️|✅|1️⃣|2️⃣|3️⃣|4️⃣|5️⃣/g, '')
      .replace(/\n{2,}/g, '. ')
      .replace(/\n/g, ' ')
      .trim();

    return await generateVoice(clean, language);
  } catch (err) {
    logger.error({ err: err.message }, 'buildVoiceReply error');
    return null;
  }
};

// ============================================================
// ShepherdAI — Express Health Server
// Required for Render Background Worker to stay alive
// EMEMZYVISUALS DIGITALS
// ============================================================

import express from 'express';
import config from './config/index.js';
import logger from './utils/logger.js';

const app = express();

app.use(express.json());

// ── Health check endpoint ─────────────────────
app.get('/', (req, res) => {
  res.status(200).json({
    status: 'online',
    service: 'ShepherdAI',
    tagline: 'Your 24/7 AI Christian Companion',
    developer: config.developer,
    uptime: Math.floor(process.uptime()),
    timestamp: new Date().toISOString(),
  });
});

app.get('/health', (req, res) => {
  const mem = process.memoryUsage();
  res.status(200).json({
    healthy: true,
    memory: {
      rss: `${Math.round(mem.rss / 1024 / 1024)}MB`,
      heapUsed: `${Math.round(mem.heapUsed / 1024 / 1024)}MB`,
    },
    node: process.version,
    env: config.nodeEnv,
  });
});

app.get('/ping', (req, res) => {
  res.status(200).send('pong');
});

// 404 handler
app.use((req, res) => {
  res.status(404).json({ error: 'Not found' });
});

export const startServer = () => {
  app.listen(config.port, () => {
    logger.info({ port: config.port }, '🌐 Health server running');
  });
};

export default app;

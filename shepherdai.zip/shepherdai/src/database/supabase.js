// ============================================================
// ShepherdAI — Supabase Database Layer
// EMEMZYVISUALS DIGITALS
// ============================================================

import axios from 'axios';
import { config } from '../config/index.js';
import logger from '../utils/logger.js';

// ─────────────────────────────────────────────
// Supabase REST client (no SDK needed, pure HTTP)
// ─────────────────────────────────────────────

const headers = () => ({
  apikey: config.supabase.serviceKey,
  Authorization: `Bearer ${config.supabase.serviceKey}`,
  'Content-Type': 'application/json',
  Prefer: 'return=representation',
});

const url = (table) => `${config.supabase.url}/rest/v1/${table}`;

const supaGet = async (table, params = {}) => {
  const res = await axios.get(url(table), {
    headers: headers(),
    params,
  });
  return res.data;
};

const supaPost = async (table, body) => {
  const res = await axios.post(url(table), body, { headers: headers() });
  return res.data;
};

const supaPatch = async (table, params, body) => {
  const res = await axios.patch(url(table), body, {
    headers: { ...headers(), Prefer: 'return=representation' },
    params,
  });
  return res.data;
};

const supaDelete = async (table, params) => {
  const res = await axios.delete(url(table), {
    headers: headers(),
    params,
  });
  return res.data;
};

// ─────────────────────────────────────────────
// USERS
// ─────────────────────────────────────────────

export const getUser = async (jid) => {
  try {
    const rows = await supaGet('users', { jid: `eq.${jid}`, limit: 1 });
    return rows[0] || null;
  } catch (err) {
    logger.error({ err, jid }, 'getUser error');
    return null;
  }
};

export const createUser = async (jid, language = 'english') => {
  try {
    const rows = await supaPost('users', {
      jid,
      language,
      created_at: new Date().toISOString(),
    });
    return rows[0] || null;
  } catch (err) {
    logger.error({ err, jid }, 'createUser error');
    return null;
  }
};

export const updateUserLanguage = async (jid, language) => {
  try {
    await supaPatch('users', { jid: `eq.${jid}` }, { language });
    logger.info({ jid, language }, 'User language updated');
  } catch (err) {
    logger.error({ err, jid }, 'updateUserLanguage error');
  }
};

export const getAllUsers = async () => {
  try {
    return await supaGet('users', { select: 'jid,language' });
  } catch (err) {
    logger.error({ err }, 'getAllUsers error');
    return [];
  }
};

export const getOrCreateUser = async (jid) => {
  let user = await getUser(jid);
  if (!user) {
    user = await createUser(jid);
    logger.info({ jid }, 'New user registered');
  }
  return user;
};

// ─────────────────────────────────────────────
// PRAYER REQUESTS
// ─────────────────────────────────────────────

export const savePrayerRequest = async (jid, request) => {
  try {
    const rows = await supaPost('prayer_requests', {
      jid,
      request,
      created_at: new Date().toISOString(),
    });
    return rows[0] || null;
  } catch (err) {
    logger.error({ err, jid }, 'savePrayerRequest error');
    return null;
  }
};

export const getPrayerRequests = async (jid, limit = 10) => {
  try {
    return await supaGet('prayer_requests', {
      jid: `eq.${jid}`,
      order: 'created_at.desc',
      limit,
    });
  } catch (err) {
    logger.error({ err, jid }, 'getPrayerRequests error');
    return [];
  }
};

// ─────────────────────────────────────────────
// FAITH STREAKS
// ─────────────────────────────────────────────

export const getFaithStreak = async (jid) => {
  try {
    const rows = await supaGet('faith_streaks', {
      jid: `eq.${jid}`,
      limit: 1,
    });
    return rows[0] || null;
  } catch (err) {
    logger.error({ err, jid }, 'getFaithStreak error');
    return null;
  }
};

export const upsertFaithStreak = async (jid) => {
  try {
    const existing = await getFaithStreak(jid);
    const today = new Date().toISOString().split('T')[0];

    if (!existing) {
      await supaPost('faith_streaks', {
        jid,
        days: 1,
        last_read: today,
      });
      return { days: 1, isNew: true };
    }

    const lastRead = existing.last_read;
    const yesterday = new Date();
    yesterday.setDate(yesterday.getDate() - 1);
    const yesterdayStr = yesterday.toISOString().split('T')[0];

    let newDays = existing.days;
    if (lastRead === today) {
      // Already read today, no change
      return { days: newDays, unchanged: true };
    } else if (lastRead === yesterdayStr) {
      // Consecutive day
      newDays += 1;
    } else {
      // Streak broken
      newDays = 1;
    }

    await supaPatch(
      'faith_streaks',
      { jid: `eq.${jid}` },
      { days: newDays, last_read: today },
    );

    return { days: newDays, broken: lastRead !== yesterdayStr };
  } catch (err) {
    logger.error({ err, jid }, 'upsertFaithStreak error');
    return { days: 0 };
  }
};

// ─────────────────────────────────────────────
// QUIZ SCORES
// ─────────────────────────────────────────────

export const getQuizScore = async (jid) => {
  try {
    const rows = await supaGet('quiz_scores', { jid: `eq.${jid}`, limit: 1 });
    return rows[0] || { jid, score: 0 };
  } catch (err) {
    logger.error({ err, jid }, 'getQuizScore error');
    return { jid, score: 0 };
  }
};

export const updateQuizScore = async (jid, increment = 1) => {
  try {
    const existing = await getQuizScore(jid);
    const newScore = (existing.score || 0) + increment;

    if (!existing.jid || existing.score === 0) {
      await supaPost('quiz_scores', { jid, score: newScore });
    } else {
      await supaPatch('quiz_scores', { jid: `eq.${jid}` }, { score: newScore });
    }
    return newScore;
  } catch (err) {
    logger.error({ err, jid }, 'updateQuizScore error');
    return 0;
  }
};

// ─────────────────────────────────────────────
// GROUPS
// ─────────────────────────────────────────────

export const saveGroup = async (groupJid) => {
  try {
    const rows = await supaGet('groups', {
      group_jid: `eq.${groupJid}`,
      limit: 1,
    });
    if (rows.length > 0) return rows[0];

    const inserted = await supaPost('groups', {
      group_jid: groupJid,
      joined_at: new Date().toISOString(),
    });
    logger.info({ groupJid }, 'New group saved');
    return inserted[0] || null;
  } catch (err) {
    logger.error({ err, groupJid }, 'saveGroup error');
    return null;
  }
};

export const getAllGroups = async () => {
  try {
    return await supaGet('groups', { select: 'group_jid' });
  } catch (err) {
    logger.error({ err }, 'getAllGroups error');
    return [];
  }
};

export const getTotalUsers = async () => {
  try {
    const users = await getAllUsers();
    return users.length;
  } catch (err) {
    return 0;
  }
};

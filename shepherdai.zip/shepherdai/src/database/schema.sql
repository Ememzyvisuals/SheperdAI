-- ============================================================
-- ShepherdAI — Supabase Database Schema
-- EMEMZYVISUALS DIGITALS
-- Run this in your Supabase SQL Editor
-- ============================================================

-- USERS TABLE
create table if not exists users (
  id bigserial primary key,
  jid text not null unique,
  language text not null default 'english',
  created_at timestamptz default now()
);

-- PRAYER REQUESTS TABLE
create table if not exists prayer_requests (
  id bigserial primary key,
  jid text not null,
  request text not null,
  created_at timestamptz default now()
);

-- FAITH STREAKS TABLE
create table if not exists faith_streaks (
  id bigserial primary key,
  jid text not null unique,
  days integer not null default 1,
  last_read date not null
);

-- QUIZ SCORES TABLE
create table if not exists quiz_scores (
  id bigserial primary key,
  jid text not null unique,
  score integer not null default 0
);

-- GROUPS TABLE
create table if not exists groups (
  id bigserial primary key,
  group_jid text not null unique,
  joined_at timestamptz default now()
);

-- Indexes for performance
create index if not exists idx_users_jid on users(jid);
create index if not exists idx_prayer_jid on prayer_requests(jid);
create index if not exists idx_streaks_jid on faith_streaks(jid);
create index if not exists idx_quiz_jid on quiz_scores(jid);
create index if not exists idx_groups_jid on groups(group_jid);

-- Row Level Security (enable for production)
alter table users enable row level security;
alter table prayer_requests enable row level security;
alter table faith_streaks enable row level security;
alter table quiz_scores enable row level security;
alter table groups enable row level security;

-- Service role bypass policy (for server-side access)
create policy "service_role_all" on users for all using (true);
create policy "service_role_all" on prayer_requests for all using (true);
create policy "service_role_all" on faith_streaks for all using (true);
create policy "service_role_all" on quiz_scores for all using (true);
create policy "service_role_all" on groups for all using (true);

-- ============================================================
-- WA SESSION TABLE (Persistent session across Render restarts)
-- ============================================================
create table if not exists wa_sessions (
  id bigserial primary key,
  session_id text not null unique,
  session_data text not null,
  updated_at timestamptz default now()
);

create index if not exists idx_wa_sessions_id on wa_sessions(session_id);
alter table wa_sessions enable row level security;
create policy "service_role_all" on wa_sessions for all using (true);

// ============================================================
// ShepherdAI — Supabase Persistent Session Store
// Stores Baileys auth state in Supabase so session survives
// Render restarts and redeploys without re-pairing
// EMEMZYVISUALS DIGITALS
// ============================================================

import axios from 'axios';
import { useMultiFileAuthState, initAuthCreds, BufferJSON } from '@whiskeysockets/baileys';
import { existsSync, mkdirSync, writeFileSync, readFileSync } from 'fs';
import { join } from 'path';
import config from '../config/index.js';
import logger from '../utils/logger.js';

const TABLE = 'wa_sessions';
const SESSION_ID = 'shepherdai_main';

const headers = () => ({
  apikey: config.supabase.serviceKey,
  Authorization: `Bearer ${config.supabase.serviceKey}`,
  'Content-Type': 'application/json',
  Prefer: 'return=representation',
});

const supaUrl = (table) => `${config.supabase.url}/rest/v1/${table}`;

// ─────────────────────────────────────────────
// Save session to Supabase
// ─────────────────────────────────────────────
export const saveSession = async (state) => {
  if (!config.supabase.url || !config.supabase.serviceKey) return;

  try {
    const sessionData = JSON.stringify(state, BufferJSON.replacer);

    // Upsert using Supabase REST
    await axios.post(
      supaUrl(TABLE),
      {
        session_id: SESSION_ID,
        session_data: sessionData,
        updated_at: new Date().toISOString(),
      },
      {
        headers: {
          ...headers(),
          Prefer: 'resolution=merge-duplicates',
        },
      }
    );
    logger.debug('Session saved to Supabase');
  } catch (err) {
    logger.warn({ err: err.message }, 'Could not save session to Supabase');
  }
};

// ─────────────────────────────────────────────
// Load session from Supabase
// Returns null if not found
// ─────────────────────────────────────────────
export const loadSession = async () => {
  if (!config.supabase.url || !config.supabase.serviceKey) return null;

  try {
    const res = await axios.get(supaUrl(TABLE), {
      headers: headers(),
      params: {
        session_id: `eq.${SESSION_ID}`,
        limit: 1,
      },
    });

    const row = res.data?.[0];
    if (!row?.session_data) return null;

    const parsed = JSON.parse(row.session_data, BufferJSON.reviver);

    // Build a compatible auth state from the stored data
    // We write it back to the local file system so Baileys can use it
    if (!existsSync(config.sessionPath)) {
      mkdirSync(config.sessionPath, { recursive: true });
    }

    // Write each key file that was saved
    if (parsed.creds) {
      writeFileSync(
        join(config.sessionPath, 'creds.json'),
        JSON.stringify(parsed.creds, BufferJSON.replacer)
      );
    }

    if (parsed.keys) {
      for (const [type, typeData] of Object.entries(parsed.keys)) {
        for (const [id, keyData] of Object.entries(typeData)) {
          const fileName = `${type}-${id}.json`;
          writeFileSync(
            join(config.sessionPath, fileName),
            JSON.stringify(keyData, BufferJSON.replacer)
          );
        }
      }
    }

    logger.info('Session data restored from Supabase to local files');

    // Now use normal multifile auth on the restored files
    const { useMultiFileAuthState } = await import('@whiskeysockets/baileys');
    return await useMultiFileAuthState(config.sessionPath);
  } catch (err) {
    logger.warn({ err: err.message }, 'Could not load session from Supabase — using file fallback');
    return null;
  }
};

// ─────────────────────────────────────────────
// Delete session (on logout)
// ─────────────────────────────────────────────
export const deleteSession = async () => {
  try {
    await axios.delete(supaUrl(TABLE), {
      headers: headers(),
      params: { session_id: `eq.${SESSION_ID}` },
    });
    logger.info('Session deleted from Supabase');
  } catch (err) {
    logger.warn({ err: err.message }, 'Could not delete session from Supabase');
  }
};

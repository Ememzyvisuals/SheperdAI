// ============================================================
// ShepherdAI — Group Events Handler
// EMEMZYVISUALS DIGITALS
// ============================================================

import config from '../config/index.js';
import { saveGroup } from '../database/supabase.js';
import messageQueue from '../utils/messageQueue.js';
import logger from '../utils/logger.js';

const BOT_JID = config.botNumber
  ? `${config.botNumber}@s.whatsapp.net`
  : null;

/**
 * Handle group participant updates
 * Fires when bot is added/removed, or members change
 */
export const handleGroupParticipantsUpdate = async (update) => {
  try {
    const { id: groupJid, participants, action } = update;

    logger.info({ groupJid, action, participants }, 'Group participant update');

    // Bot was added to a group
    if (action === 'add' && participants.includes(BOT_JID)) {
      await saveGroup(groupJid);
      await sendGroupWelcome(groupJid);
    }

    // Bot was removed
    if (action === 'remove' && participants.includes(BOT_JID)) {
      logger.info({ groupJid }, 'Bot removed from group');
    }

    // New member joined
    if (action === 'add' && !participants.includes(BOT_JID)) {
      await sendMemberWelcome(groupJid, participants);
    }
  } catch (err) {
    logger.error({ err: err.message }, 'handleGroupParticipantsUpdate error');
  }
};

/**
 * Send welcome message when bot joins a group
 */
const sendGroupWelcome = async (groupJid) => {
  const welcome =
    `✝️ *Praise the Lord!* 🙏\n\n` +
    `I am *ShepherdAI*, your AI Christian companion by *${config.developer}*.\n\n` +
    `I'm here to help this group grow in faith through:\n` +
    `📖 Daily Bible verses\n` +
    `🙏 Prayer & devotionals\n` +
    `🎯 Bible quizzes\n` +
    `💬 Christian encouragement\n\n` +
    `To use me, mention my name or use commands like:\n` +
    `*/verse* • */devotional* • */quiz* • */pray* • */help*\n\n` +
    `_"Where two or three are gathered in my name, there am I among them." — Matthew 18:20_ ✝️`;

  await messageQueue.sendText(groupJid, welcome);
};

/**
 * Welcome new member to group
 */
const sendMemberWelcome = async (groupJid, participants) => {
  const names = participants.map((p) => `@${p.split('@')[0]}`).join(' ');
  const welcome =
    `🙏 Welcome ${names} to the group!\n\n` +
    `_"Therefore welcome one another as Christ has welcomed you, for the glory of God."_\n` +
    `— Romans 15:7 ✝️`;

  await messageQueue.sendText(groupJid, welcome);
};

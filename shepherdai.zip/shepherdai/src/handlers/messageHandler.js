// ============================================================
// ShepherdAI — Message Handler
// EMEMZYVISUALS DIGITALS
// ============================================================

import config from '../config/index.js';
import { handleCommand } from '../commands/index.js';
import { generateAIResponse } from '../services/groqService.js';
import { transcribeVoiceNote, buildVoiceReply } from '../services/voiceService.js';
import { checkMessage, getModerationResponse, shouldRespondInGroup } from '../services/moderationService.js';
import { getOrCreateUser, updateUserLanguage, savePrayerRequest, upsertFaithStreak } from '../database/supabase.js';
import {
  getHistory,
  addToHistory,
  getQuizState,
  clearQuizState,
  isPendingLanguage,
  clearPendingLanguage,
  setPendingLanguage,
} from '../services/conversationCache.js';
import { LANGUAGE_MENU, LANGUAGE_CONFIRMATIONS, parseLanguageChoice } from '../utils/languageRouter.js';
import { checkRateLimit } from '../utils/rateLimiter.js';
import { sendChunked } from '../utils/chunkMessage.js';
import messageQueue from '../utils/messageQueue.js';
import logger from '../utils/logger.js';

/**
 * Extract text content from a Baileys message
 */
const extractText = (msg) => {
  const m = msg.message;
  if (!m) return '';
  return (
    m.conversation ||
    m.extendedTextMessage?.text ||
    m.imageMessage?.caption ||
    m.videoMessage?.caption ||
    m.buttonsResponseMessage?.selectedButtonId ||
    m.listResponseMessage?.singleSelectReply?.selectedRowId ||
    ''
  ).trim();
};

/**
 * Check if message is a voice note
 */
const isVoiceNote = (msg) => {
  const m = msg.message;
  return !!(m?.audioMessage?.ptt || m?.audioMessage);
};

/**
 * Get voice note data from message
 */
const getAudioData = (msg) => {
  const audio = msg.message?.audioMessage;
  if (!audio) return null;
  return {
    mimetype: audio.mimetype || 'audio/ogg; codecs=opus',
    fileLength: audio.fileLength,
  };
};

/**
 * Extract sender JID (handles groups correctly)
 */
const getSender = (msg) => {
  return msg.key.participant || msg.key.remoteJid || '';
};

/**
 * Check if JID is a group
 */
const isGroupJid = (jid) => jid?.endsWith('@g.us') || false;

// ─────────────────────────────────────────────
// MAIN MESSAGE HANDLER
// ─────────────────────────────────────────────

export const handleIncomingMessage = async (sock, msg) => {
  try {
    // Ignore messages from self
    if (msg.key.fromMe) return;

    const jid = msg.key.remoteJid;
    const sender = getSender(msg);
    const isGroup = isGroupJid(jid);
    const isOwner = sender === config.ownerJid || sender.split('@')[0] === config.ownerNumber;

    // Ignore status broadcasts
    if (jid === 'status@broadcast') return;

    const text = extractText(msg);
    const hasAudio = isVoiceNote(msg);

    // If no usable content, skip
    if (!text && !hasAudio) return;

    // ── Rate limit check ──────────────────────
    if (!isOwner && !checkRateLimit(sender)) {
      logger.warn({ sender }, 'Rate limited');
      return;
    }

    // ── Group filter ──────────────────────────
    if (isGroup) {
      if (
        text &&
        !shouldRespondInGroup(text, config.botNumber + '@s.whatsapp.net', config.botName)
      ) {
        // Check moderation regardless
        const { flagged } = checkMessage(text);
        if (flagged) {
          await messageQueue.sendText(jid, getModerationResponse());
        }
        return;
      }
    }

    // ── Get/create user ──────────────────────
    const user = await getOrCreateUser(sender);
    const language = user?.language || 'english';

    logger.info({ sender, jid, isGroup, text: text.slice(0, 50) }, 'Incoming message');

    // ── First time user: language selection ──
    if (!user?.language || user.language === 'english') {
      // Check if this is a brand new user (no language set yet)
      const isNewUser = !user?.language;
      if (isNewUser && !isPendingLanguage(sender)) {
        setPendingLanguage(sender);
        await messageQueue.sendText(jid, LANGUAGE_MENU, msg);
        return;
      }
    }

    // ── Pending language selection ────────────
    if (isPendingLanguage(sender) && text) {
      const choice = parseLanguageChoice(text);
      if (choice) {
        await updateUserLanguage(sender, choice);
        clearPendingLanguage(sender);
        await messageQueue.sendText(
          jid,
          LANGUAGE_CONFIRMATIONS[choice],
          msg,
        );
        // Send welcome after language selected
        await messageQueue.sendText(
          jid,
          `🙏 *Welcome to ShepherdAI!*\n\nI'm your 24/7 Christian companion.\n\nSend */help* to see all commands, or just chat with me naturally!\n\n_"I am the way, the truth, and the life." — John 14:6_`,
          null,
        );
        return;
      } else {
        await messageQueue.sendText(
          jid,
          '❓ Please choose a valid option:\n\n1️⃣ English\n2️⃣ Pidgin\n3️⃣ Yoruba\n4️⃣ Igbo\n5️⃣ Hausa\n\nReply with the number.',
          msg,
        );
        return;
      }
    }

    // ── Group moderation check ────────────────
    if (isGroup && text) {
      const { flagged } = checkMessage(text);
      if (flagged) {
        await messageQueue.sendText(jid, getModerationResponse());
        return;
      }
    }

    // ── Handle voice note ─────────────────────
    if (hasAudio) {
      await handleVoiceMessage(sock, msg, jid, sender, user, language);
      return;
    }

    // ── Handle commands (/cmd) ────────────────
    if (text.startsWith('/')) {
      const handled = await handleCommand({
        jid,
        sender,
        text,
        msg,
        isGroup,
        isOwner,
        user,
        sock,
      });
      if (handled) return;
    }

    // ── Handle quiz answer ────────────────────
    const quizState = getQuizState(sender);
    if (quizState && /^[abcdABCD]$/.test(text.trim())) {
      await handleQuizAnswer(jid, sender, text.trim().toUpperCase(), quizState, msg, language);
      return;
    }

    // ── Prayer request detection ───────────────
    const prayerTriggers = [
      /pray for/i, /please pray/i, /i need prayer/i, /prayer request/i,
      /lord help/i, /god please/i, /father help/i,
    ];
    const isPrayerRequest = prayerTriggers.some((r) => r.test(text));
    if (isPrayerRequest) {
      await savePrayerRequest(sender, text);
      await messageQueue.sendText(jid, '🙏 I have your request...', msg);
      const { generatePrayer } = await import('../services/groqService.js');
      const prayer = await generatePrayer(text, language);
      await sendChunked(messageQueue, jid, prayer, null);
      addToHistory(sender, 'user', text);
      addToHistory(sender, 'assistant', prayer);
      return;
    }

    // ── General AI conversation ───────────────
    await handleAIConversation(jid, sender, text, msg, language);
  } catch (err) {
    logger.error({ err: err.message }, 'handleIncomingMessage error');
  }
};

// ─────────────────────────────────────────────
// VOICE NOTE HANDLER
// ─────────────────────────────────────────────

const handleVoiceMessage = async (sock, msg, jid, sender, user, language) => {
  try {
    await messageQueue.sendText(jid, '🎙️ Processing your voice note...', msg);

    // Download voice note buffer using Baileys downloadMediaMessage
    const { downloadMediaMessage } = await import('@whiskeysockets/baileys');
    const audioBuffer = await downloadMediaMessage(msg, 'buffer', {}, {
      logger,
      reuploadRequest: sock.updateMediaMessage,
    });

    if (!audioBuffer || audioBuffer.length === 0) {
      await messageQueue.sendText(jid, '⚠️ Could not read your voice note. Please try again.', msg);
      return;
    }

    const audioData = getAudioData(msg);
    const transcript = await transcribeVoiceNote(audioBuffer, audioData?.mimetype);

    if (!transcript) {
      await messageQueue.sendText(
        jid,
        '⚠️ Could not understand the voice note. Please try sending a text message. 🙏',
        msg,
      );
      return;
    }

    logger.info({ sender, transcript: transcript.slice(0, 60) }, 'Voice note transcribed');
    await messageQueue.sendText(jid, `📝 _I heard: "${transcript}"_`, msg);

    // Process transcribed text as regular message
    await handleAIConversation(jid, sender, transcript, null, language, true);
  } catch (err) {
    logger.error({ err: err.message }, 'handleVoiceMessage error');
    await messageQueue.sendText(
      jid,
      '⚠️ Error processing voice note. Please try again. 🙏',
      msg,
    );
  }
};

// ─────────────────────────────────────────────
// AI CONVERSATION
// ─────────────────────────────────────────────

const handleAIConversation = async (jid, sender, text, msg, language, replyWithVoice = false) => {
  try {
    const history = getHistory(sender);
    const response = await generateAIResponse(text, language, history);

    addToHistory(sender, 'user', text);
    addToHistory(sender, 'assistant', response);

    // Send text response
    await sendChunked(messageQueue, jid, response, msg);

    // Optionally send voice reply for voice note inputs
    if (replyWithVoice) {
      const audio = await buildVoiceReply(response, language);
      if (audio) {
        await messageQueue.sendAudio(jid, audio, 'audio/wav', null);
      }
    }
  } catch (err) {
    logger.error({ err: err.message, sender }, 'AI conversation error');
    await messageQueue.sendText(
      jid,
      '🙏 I\'m having trouble right now. Please try again in a moment.',
      msg,
    );
  }
};

// ─────────────────────────────────────────────
// QUIZ ANSWER HANDLER
// ─────────────────────────────────────────────

const handleQuizAnswer = async (jid, sender, answer, question, msg, language) => {
  try {
    clearQuizState(sender);
    const { updateQuizScore, getQuizScore } = await import('../database/supabase.js');

    const isCorrect = answer === question.answer;
    let newScore = 0;

    if (isCorrect) {
      newScore = await updateQuizScore(sender, 1);
    } else {
      const scoreRow = await getQuizScore(sender);
      newScore = scoreRow.score || 0;
    }

    const resultText = isCorrect
      ? `✅ *Correct!* 🎉\n\n📖 ${question.explanation}\n\n🏆 Your score: *${newScore} points*\n\n_Send */quiz* for another question!_`
      : `❌ *Not quite!*\n\nThe correct answer was *${question.answer}*.\n\n📖 ${question.explanation}\n\n🏆 Your score: *${newScore} points*\n\n_Try another with */quiz*!_`;

    await messageQueue.sendText(jid, resultText, msg);
  } catch (err) {
    logger.error({ err: err.message }, 'handleQuizAnswer error');
  }
};

// ============================================================
// ShepherdAI — Command Dispatcher
// EMEMZYVISUALS DIGITALS
// ============================================================

import config from '../config/index.js';
import {
  generateAIResponse,
  generatePrayer,
  generateDevotion,
  generateSermonOutline,
} from '../services/groqService.js';
import {
  searchBibleTopic,
  formatVerseResults,
  getRandomQuizQuestion,
} from '../services/bibleEngine.js';
import {
  getAllUsers,
  getTotalUsers,
  getAllGroups,
  savePrayerRequest,
  getFaithStreak,
} from '../database/supabase.js';
import {
  setQuizState,
  clearHistory,
} from '../services/conversationCache.js';
import { sendChunked } from '../utils/chunkMessage.js';
import { generateVoice } from '../utils/ttsRouter.js';
import messageQueue from '../utils/messageQueue.js';
import logger from '../utils/logger.js';

/**
 * All registered bot commands
 * Keys are lowercase command triggers (without slash)
 */
export const COMMANDS = {
  // ── Help ──────────────────────────────────
  help: {
    description: 'Show all commands',
    ownerOnly: false,
  },
  // ── Bible ─────────────────────────────────
  verse: {
    description: 'Get a Bible verse on a topic — /verse fear',
    ownerOnly: false,
  },
  devotional: {
    description: 'Get today\'s devotional',
    ownerOnly: false,
  },
  pray: {
    description: 'Request a prayer — /pray my exams',
    ownerOnly: false,
  },
  sermon: {
    description: 'Get sermon outline — /sermon grace',
    ownerOnly: false,
  },
  quiz: {
    description: 'Start a Bible quiz',
    ownerOnly: false,
  },
  streak: {
    description: 'Check your faith streak',
    ownerOnly: false,
  },
  voice: {
    description: 'Get a voice devotional',
    ownerOnly: false,
  },
  language: {
    description: 'Change your language',
    ownerOnly: false,
  },
  reset: {
    description: 'Clear conversation history',
    ownerOnly: false,
  },
  about: {
    description: 'About ShepherdAI',
    ownerOnly: false,
  },
  // ── Owner ─────────────────────────────────
  broadcast: {
    description: '[Owner] Broadcast to all users',
    ownerOnly: true,
  },
  users: {
    description: '[Owner] Total registered users',
    ownerOnly: true,
  },
  stats: {
    description: '[Owner] Bot statistics',
    ownerOnly: true,
  },
  restart: {
    description: '[Owner] Restart the bot',
    ownerOnly: true,
  },
};

/**
 * Build help menu text
 */
const buildHelpText = (isOwner = false) => {
  const publicCmds = Object.entries(COMMANDS)
    .filter(([, v]) => !v.ownerOnly)
    .map(([k, v]) => `  /${k} — ${v.description}`)
    .join('\n');

  const ownerCmds = isOwner
    ? '\n\n👑 *Owner Commands:*\n' +
      Object.entries(COMMANDS)
        .filter(([, v]) => v.ownerOnly)
        .map(([k, v]) => `  /${k} — ${v.description}`)
        .join('\n')
    : '';

  return `📖 *ShepherdAI Commands* 🙏\n_Your 24/7 AI Christian Companion_\n_by ${config.developer}_\n\n${publicCmds}${ownerCmds}\n\n✝️ _Or just chat naturally — I understand plain messages too!_`;
};

/**
 * Main command handler
 * @param {object} ctx - { jid, sender, text, msg, isGroup, isOwner, user, sock }
 */
export const handleCommand = async (ctx) => {
  const { jid, sender, text, msg, isOwner, user, sock } = ctx;
  const language = user?.language || 'english';
  const queue = messageQueue;

  // Parse command and args
  const parts = text.trim().split(/\s+/);
  const cmd = parts[0].slice(1).toLowerCase(); // remove leading /
  const args = parts.slice(1).join(' ').trim();

  // Check if command exists
  if (!COMMANDS[cmd]) return false;

  // Check owner-only
  if (COMMANDS[cmd].ownerOnly && !isOwner) {
    await queue.sendText(
      jid,
      '⛔ This command is reserved for the bot owner.',
      msg,
    );
    return true;
  }

  logger.info({ cmd, jid, args }, 'Command executed');

  try {
    switch (cmd) {
      // ── /help ──────────────────────────────
      case 'help': {
        await queue.sendText(jid, buildHelpText(isOwner), msg);
        break;
      }

      // ── /about ─────────────────────────────
      case 'about': {
        const aboutText = `✝️ *ShepherdAI*\n_Your 24/7 AI Christian Companion_\n\n👨‍💻 *Developer:* ${config.developer}\n🤖 *Powered by:* Groq AI (llama-3.3-70b)\n🌍 *Languages:* English, Pidgin, Yoruba, Igbo, Hausa\n🎙️ *Voice:* Groq Orpheus + HuggingFace MMS\n📖 *Mission:* Helping Christians grow spiritually\n\n_"Your word is a lamp to my feet and a light to my path." — Psalm 119:105_`;
        await queue.sendText(jid, aboutText, msg);
        break;
      }

      // ── /verse ─────────────────────────────
      case 'verse': {
        if (!args) {
          await queue.sendText(
            jid,
            '📖 Please provide a topic!\nExample: */verse fear*',
            msg,
          );
          break;
        }
        const verses = searchBibleTopic(args);
        const formatted = formatVerseResults(verses, args);
        await sendChunked(queue, jid, formatted, msg);
        break;
      }

      // ── /devotional ────────────────────────
      case 'devotional': {
        await queue.sendText(jid, '📖 Preparing your devotional... 🙏', msg);
        const devo = await generateDevotion(language);
        await sendChunked(queue, jid, devo, null);
        break;
      }

      // ── /pray ──────────────────────────────
      case 'pray': {
        const request = args || 'my needs today';
        await queue.sendText(jid, '🙏 Lifting this to the Lord...', msg);
        await savePrayerRequest(sender, request);
        const prayer = await generatePrayer(request, language);
        await sendChunked(queue, jid, prayer, null);
        break;
      }

      // ── /sermon ────────────────────────────
      case 'sermon': {
        if (!args) {
          await queue.sendText(
            jid,
            '📖 Please provide a topic!\nExample: */sermon grace*',
            msg,
          );
          break;
        }
        await queue.sendText(jid, '📝 Preparing sermon outline...', msg);
        const sermon = await generateSermonOutline(args, language);
        await sendChunked(queue, jid, sermon, null);
        break;
      }

      // ── /quiz ──────────────────────────────
      case 'quiz': {
        const question = getRandomQuizQuestion();
        setQuizState(sender, question);
        const quizText =
          `🎯 *Bible Quiz Time!* 📖\n\n` +
          `*Q: ${question.question}*\n\n` +
          question.options.join('\n') +
          `\n\n_Reply with A, B, C, or D_`;
        await queue.sendText(jid, quizText, msg);
        break;
      }

      // ── /streak ────────────────────────────
      case 'streak': {
        const streak = await getFaithStreak(sender);
        if (!streak) {
          await queue.sendText(
            jid,
            '🔥 You have no streak yet! Read your first devotional with */devotional* to start! 📖',
            msg,
          );
        } else {
          const fire = '🔥'.repeat(Math.min(streak.days, 10));
          await queue.sendText(
            jid,
            `${fire}\n\n*Faith Streak: ${streak.days} day${streak.days !== 1 ? 's' : ''}!*\n\n_Last read: ${streak.last_read}_\n\n_"Blessed is the one who reads aloud the words of this prophecy." (Rev 1:3)_`,
            msg,
          );
        }
        break;
      }

      // ── /voice ─────────────────────────────
      case 'voice': {
        await queue.sendText(jid, '🎙️ Preparing voice devotional...', msg);
        const devo = await generateDevotion(language);
        const audio = await generateVoice(devo, language);
        if (audio) {
          await queue.sendAudio(jid, audio, 'audio/wav', msg);
        } else {
          await sendChunked(queue, jid, devo, msg);
          await queue.sendText(
            jid,
            '_(Voice generation unavailable, sent as text)_',
            null,
          );
        }
        break;
      }

      // ── /language ──────────────────────────
      case 'language': {
        const { LANGUAGE_MENU } = await import('../utils/languageRouter.js');
        const { setPendingLanguage } = await import('../services/conversationCache.js');
        setPendingLanguage(sender);
        await queue.sendText(jid, LANGUAGE_MENU, msg);
        break;
      }

      // ── /reset ─────────────────────────────
      case 'reset': {
        clearHistory(sender);
        await queue.sendText(
          jid,
          '🔄 Conversation history cleared. Fresh start! 🙏',
          msg,
        );
        break;
      }

      // ── OWNER: /broadcast ──────────────────
      case 'broadcast': {
        if (!args) {
          await queue.sendText(
            jid,
            '📢 Usage: */broadcast Your message here*',
            msg,
          );
          break;
        }
        const users = await getAllUsers();
        await queue.sendText(
          jid,
          `📢 Broadcasting to *${users.length}* users...`,
          msg,
        );

        let sent = 0;
        for (const u of users) {
          try {
            // Only broadcast to prior users (safe broadcast rule)
            if (u.jid && u.jid !== sender) {
              await queue.sendText(
                u.jid,
                `📢 *Message from ShepherdAI*\n\n${args}\n\n_— ${config.developer}_`,
              );
              sent++;
            }
          } catch (_) {}
        }
        await queue.sendText(
          jid,
          `✅ Broadcast sent to *${sent}* users.`,
          null,
        );
        break;
      }

      // ── OWNER: /users ──────────────────────
      case 'users': {
        const total = await getTotalUsers();
        const groups = await getAllGroups();
        await queue.sendText(
          jid,
          `👥 *ShepherdAI Statistics*\n\n📱 Total Users: *${total}*\n👥 Groups: *${groups.length}*`,
          msg,
        );
        break;
      }

      // ── OWNER: /stats ──────────────────────
      case 'stats': {
        const total = await getTotalUsers();
        const groups = await getAllGroups();
        const mem = process.memoryUsage();
        const uptime = Math.floor(process.uptime() / 3600);
        const statsText =
          `📊 *ShepherdAI Stats*\n` +
          `_by ${config.developer}_\n\n` +
          `👥 Users: *${total}*\n` +
          `🏘️ Groups: *${groups.length}*\n` +
          `⏱️ Uptime: *${uptime}h*\n` +
          `💾 Memory: *${Math.round(mem.rss / 1024 / 1024)}MB*\n` +
          `🌿 Node: *${process.version}*\n` +
          `🔧 Env: *${config.nodeEnv}*`;
        await queue.sendText(jid, statsText, msg);
        break;
      }

      // ── OWNER: /restart ────────────────────
      case 'restart': {
        await queue.sendText(jid, '🔄 Restarting ShepherdAI...', msg);
        setTimeout(() => process.exit(0), 2000);
        break;
      }

      default:
        return false;
    }
  } catch (err) {
    logger.error({ err: err.message, cmd }, 'Command handler error');
    await queue.sendText(
      jid,
      '⚠️ Something went wrong. Please try again or rephrase your request. 🙏',
      msg,
    );
  }

  return true;
};
